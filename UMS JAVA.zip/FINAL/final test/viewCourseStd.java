import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class viewCourseStd extends JFrame implements ActionListener
{
	private JTextField search_field;
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back, search;
	private JPanel panel;
	//private String o_id, o_name, of_pass, a_id, od_id;
	AddDropStudent ads;
	
	public viewCourseStd(AddDropStudent ads)
	{
		super("All Students");
		this.setSize(800,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		String columns[] =  {"Course","Class","Student Name","Student ID"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
		// specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,50,650,250);
		panel.add(tableScrollPane);
		
		this.ads=ads;
		
		search = new JButton("SEARCH");
		search.setBounds(350, 320, 100, 30);
		search.addActionListener(this);
		panel.add(search);
		
		search_field = new JTextField("Student Name");
		search_field.setBounds(200,320,100,30);
		panel.add(search_field);
		
		back = new JButton("Back");
		back.setBounds(470, 320, 100, 30);
		back.addActionListener(this);
		panel.add(back);

	
		
		
		//String query = "SELECT `regestration`.`r_name`,`regestration`.`hsc_reg_no`,`regestration`.`ssc_gpa`,`regestration`.`hsc_gpa`,`addmission_exam`.`marks_ob` FROM `regestration`,`addmission_exam` where `regestration`.`hsc_reg_no`=`addmission_exam`.`hsc_reg_no` ;";     
      String query ="SELECT regestration.r_name,addmission.s_id,s_course.class_id,course.c_name FROM course,f_course,addmission,regestration,s_course where regestration.hsc_reg_no=addmission.hsc_reg_no and s_course.s_id=addmission.s_id and s_course.class_id=f_course.class_id and f_course.c_id=course.c_id;";

    	Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
                String name = rs.getString("r_name");
                String s_id = rs.getString("s_id");
			     String class_id = rs.getString("class_id");
                String c_name = rs.getString("c_name");
				
				tableModel.addRow(new Object[]{c_name, class_id,name , s_id});
			}
		}
		catch(Exception e){}

		this.add(panel);
	}
	
	
	public void Search()
	{
		String std_name=search_field.getText();
	
		String columns[] =  {"Course","Class","Student Name","Student ID"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,50,650,250);
		panel.add(tableScrollPane);

		//String query = "SELECT `regestration`.`r_name`,`regestration`.`hsc_reg_no`,`regestration`.`ssc_gpa`,`regestration`.`hsc_gpa`,`addmission_exam`.`marks_ob` FROM `regestration`,`addmission_exam` where `regestration`.`hsc_reg_no`=`addmission_exam`.`hsc_reg_no` ;";     
        String query ="SELECT regestration.r_name,addmission.s_id,s_course.class_id,course.c_name FROM course,f_course,addmission,regestration,s_course where regestration.hsc_reg_no=addmission.hsc_reg_no and s_course.s_id=addmission.s_id and s_course.class_id=f_course.class_id and f_course.c_id=course.c_id;";
		Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
                   String name = rs.getString("r_name");
                String s_id = rs.getString("s_id");
			     String class_id = rs.getString("class_id");
                String c_name = rs.getString("c_name");
				
				if(name.contains(std_name))
					{
								tableModel.addRow(new Object[]{c_name, class_id,name , s_id});
									  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search.getText()))
		{
			Search();
		}
		else if(buttonClicked.equals(back.getText()))
		{
	
			ads.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
