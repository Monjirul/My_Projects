import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

public class Tpe extends JFrame implements ActionListener
{
	JLabel title,title1,title2;
	JButton logout,back,done,next;
	JRadioButton r1, r2, r3, r4, r5;
	ButtonGroup bg;
	JTextField Comment;
    JPanel panel;
	String Faculty[]=new String[10];//mk
	String Course[]=new String[10];//mk
	String q[]= new String [10];
    String s_id;
	int arr[];
	
	StudentHome sh;
	//int arr =new int [4];
	int count=0,f_count=0;
	public Tpe(String s_id,StudentHome sh)
	{
		super("TPE");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800, 1000);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.GRAY);
		arr =new int [10];
		this.s_id=s_id;
		
		this.sh=sh;
		
	q[0] ="HAVE KNOWLEDGE OF THE SUBJECT MATTER?";
	q[1] ="USEGES INSTRUCTIONAL MOTIVATION TECHNIQUES?";
	q[2] ="HAVE GOOD PERSONALITY TRAITS?";
	q[3] ="MAINTAINS GOOD STUDENT-FACULTY RELATION?";
	q[4] ="MAINTAINS ROUTINE?";
	
		TeacherNcourse();
		
		
		
		title = new JLabel("Faculty :"+Faculty[f_count]);
		title.setBounds(30,50,180,40);
		title.setBackground(Color.BLUE);
		title.setForeground(Color.white);
		title.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,12));
		title.setOpaque(true);
		panel.add(title);
		
		title1 = new JLabel("COUESE NAME :"+Course[f_count]);
		title1.setBounds(220,50,180,40);
		title1.setBackground(Color.BLUE);
		title1.setForeground(Color.white);
		title1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,12));
		title1.setOpaque(true);
		panel.add(title1);
		
		title2 = new JLabel(q[count]);
		title2.setBounds(30,100,550,80);
		title2.setBackground(Color.BLUE);
		title2.setForeground(Color.white);
		title2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		title2.setOpaque(true);
		panel.add(title2);
		
		Comment = new JTextField("");
		Comment.setBounds(100, 200,250, 250);
		//idTF.setBackground(Color.YELLOW);
		panel.add(Comment);
		Comment.setVisible(false);
		
		r1 = new JRadioButton("Strongly Agree");
		r1.setBounds(100,200,150,30);
		panel.add(r1);
		
		r2 = new JRadioButton("Agree");
		r2.setBounds(100,250,150,30);
		panel.add(r2);
		
		r3 = new JRadioButton("Moderately Agree");
		r3.setBounds(100,300,150,30);
		panel.add(r3);
		
		r4 = new JRadioButton("Least Agree");
		r4.setBounds(100,350,150,30);
		panel.add(r4);
		
		r5 = new JRadioButton("Disagree");
		r5.setBounds(100,400,150,30);
		panel.add(r5);
		
		bg= new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		bg.add(r4);
		bg.add(r5);
		
		logout = new JButton("Logout");     
		logout.setBounds(150, 470, 100, 40);
		logout.addActionListener(this);
		panel.add(logout);
		
		back= new JButton("back");
		back.setBounds(350, 470, 100, 40);
		//back.setBackground(Color.RED);
		//exit.addMouseListener(this);
		back.addActionListener(this);
		panel.add(back);
		
		back.setVisible(false);
		
		 next= new JButton("next");
		 next.setBounds(350, 470, 100, 40);
		//back.setBackground(Color.RED);
		//exit.addMouseListener(this);
		next.addActionListener(this);
		panel.add(next);
		
		done = new JButton("DONE");     
		done.setBounds(260, 520, 100, 40);
		done.addActionListener(this);
		panel.add(done);
		done.setVisible(false);
		this.add(panel);
		
	}
	public void actionPerformed(ActionEvent ae)
	{
	  String elementText = ae.getActionCommand();
	 
	 if(f_count<0)
	 {
		 title2.setText("TPE COMPLETED");
		 		r1.setVisible(false);
				r2.setVisible(false);
				r3.setVisible(false);
				r4.setVisible(false);
				r5.setVisible(false);
				next.setVisible(false);
				back.setVisible(true);
				done.setVisible(false);
				Comment.setVisible(false);
		 JOptionPane.showMessageDialog(this,"TPE Completed");
		   sh.setVisible(true);
		  this.setVisible(false);
	 }
	 if(elementText.equals(back.getText()))
	  {
		  sh.setVisible(true);
		  this.setVisible(false);
	  }
	  else if(elementText.equals(done.getText()))
	  {
if(f_count>=0)
{	
		 insertIntoDB();
		  f_count--;
		  count=0;


				title2.setText(q[count]);
				r1.setVisible(true);
				r2.setVisible(true);
				r3.setVisible(true);
				r4.setVisible(true);
				r5.setVisible(true);
				next.setVisible(true);
				back.setVisible(false);
				done.setVisible(false);
				Comment.setVisible(false);
	  }
else{JOptionPane.showMessageDialog(this,"TPE Completed");}	  
	  }
	  else  if(elementText.equals(logout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
			
		}
		
		else if(elementText.equals(next.getText()))
		{
			if(count>=4)
			{
				title2.setText("COMMENT");
				r1.setVisible(false);
				r2.setVisible(false);
				r3.setVisible(false);
				r4.setVisible(false);
				r5.setVisible(false);
				next.setVisible(false);
				back.setVisible(true);
				done.setVisible(true);
				Comment.setVisible(true);
				
			}
			else if((r1.isSelected()||r2.isSelected()||r3.isSelected()||r4.isSelected()||r5.isSelected()))
			{//System.out.println("DHUKSE");
				if(r1.isSelected())
			{
				arr[count]=5;
			}
			else if(r2.isSelected())
			{
				arr[count]=4;
			}
			else if(r3.isSelected())
			{
				arr[count]=3;
			}
			else if(r4.isSelected())
			{
				arr[count]=2;
			}
					
			else if(r5.isSelected())
			{
				arr[count]=1;
			}
			count++;
			title2.setText(q[count]);
			}
			else{//System.out.println("DHUKSE");
			}
		}
		else{JOptionPane.showMessageDialog(this,"Please Give Your Opinion.");}
	}
		
		
		public void insertIntoDB()
	{
		//int i1=arr[0],i2=arr[1],i3=arr[2],i4=arr[3],i5=arr[4];
		String cmnt=Comment.getText();
		
		String q="INSERT INTO  tpe VALUES('"+cmnt+"','"+arr[0]+"','"+arr[1]+"','"+arr[2]+"','"+arr[3]+"','"+arr[4]+"','"+Faculty[f_count]+"');";
		
		//String q="INSERT INTO classes VALUES ('"+section_name.getText()+"','"+f_id+"','"+officer_name.getText()+"','"+officer_id.getText()+"');";
    	//String q="INSERT INTO  tpe ('"+Comment.getText()+"','i1','i2','i3','i4','i5','"+t_id+"');";

	   try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root", "");
			Statement stm = con.createStatement();
			stm.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	
	
	public void TeacherNcourse()
	{
		
	  //String query1="SELECT  `s_id`, `hsc_reg_no`,`dept_id` FROM `addmission`;";
	 // String query2 = "SELECT `hsc_reg_no`, `r_name` FROM `regestration`;" ;
	
	String query="SELECT faculties.f_name,course.c_name FROM faculties,course,f_course,s_course where s_course.s_id='"+s_id+"' and f_course.class_id=s_course.class_id and f_course.f_id=faculties.f_id and course.c_id=f_course.c_id;";
	    Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
	int i=0;
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			while(rs.next())
			{
			
         	Faculty[i]  = rs.getString("f_name");
			Course[i] = rs.getString("c_name");
			
			System.out.println(Faculty[i]);
			System.out.println(Course[i]);
               i++;
	         }
		if(i==0)
		{
			JOptionPane.showMessageDialog(this,"Don't Have Any Faculty");
		}
		else{f_count=i-1;}
		
		}
		catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
	}
	
}