import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class JtableLibrary extends JFrame implements ActionListener
{
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JPasswordField pf;
	private JButton back,srch;
	private JPanel panel;
	 private JLabel title,SrcBookLabel,imgLabel;
	  private ImageIcon img;	
	 StudentHome sh;
	 int B_sts;
	 private JTextField SrcBookTF;
	public JtableLibrary (StudentHome sh)
	{
		super("");
		//this.setSize(800,600);
		this.setSize(818, 493);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		this.sh=sh;
		
		
		title = new JLabel("LIBRARY");
		title.setBounds(280,80,250,100);
		//title.setBackground(Color.GREEN);
		title.setForeground(Color.white);
		title.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		//title.setOpaque(true);
		panel.add(title);
		
		SrcBookLabel = new JLabel("Search Books	:");
		SrcBookLabel.setBounds(300, 360, 150, 20);
		SrcBookLabel.setForeground(Color.white);
		SrcBookLabel.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,12));
		panel.add(SrcBookLabel);
		
		SrcBookTF = new JTextField();
		SrcBookTF.setBounds(450, 360, 150, 20);
		panel.add(SrcBookTF);
		
		srch = new JButton("Search");
		srch.setBounds(450, 400, 150, 30);
		srch.addActionListener(this);
		panel.add(srch);
		
		
		back = new JButton("Back");
		back.setBounds(100, 400, 200, 30);
		back.addActionListener(this);
		panel.add(back);
		
		
		
		String columns[] = {"Book ID", "Book Name", "Available Copies"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,3); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(180,160,300,100);
		panel.add(tableScrollPane);
		
		
		  		
        
		Connection con=null;//for connection
        //Connection con2=null;
		Statement st = null;//for query execution
		//Statement st2 = null;
		ResultSet rs = null;//to get row by row result from DB
		//ResultSet rs2= null;
		
 
		try
		{
			String query = "SELECT `b_id`, `b_name` FROM `library`;";  
        //String query2 = "SELECT `b_name`,`borrowed_book`.`b_id`,`brorrow_date`,`return_date`,`s_id` FROM `borrowed_book`,`library` where `library`.`b_id`=`borrowed_book`.`b_id`;";
			
	
			
			String book_id="";
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
		
			while(rs.next())
			{
				System.out.println("results received sssssss");
				String Available="";
                String b_id = rs.getString("b_id");
                String b_name = rs.getString("b_name");
				Available=Avbl(b_id);
			tableModel.addRow(new Object[]{b_id, b_name, Available});


				
			}
		}
		catch(Exception e){}
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		this.add(panel);
	}
	
	public String Avbl(String b_id)
	{
		
		Connection con=null;//for connection
     
		Statement st = null;//for query execution
		
		ResultSet rs = null;//to get row by row result from DB
		
		String Available="";
 
		try
		{
			//String query = "SELECT `b_id`, `b_name` FROM `library`;";  
        //String query2 = "SELECT `b_name`,`borrowed_book`.`b_id`,`brorrow_date`,`return_date`,`s_id` FROM `borrowed_book`,`library` where `library`.`b_id`=`borrowed_book`.`b_id`;";
	String query2="SELECT IFNULL((lib_inv.copies-COUNT(borrowed_book.b_id))+1,10) FROM borrowed_book,lib_inv,library WHERE `lib_inv`.`b_id`='"+b_id+"'"+" and"+" `borrowed_book`.`b_id`='"+b_id+"' ;";

			
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query2);//getting result
			System.out.println("results received");
		
			while(rs.next())
			{
			Available=rs.getString("IFNULL((lib_inv.copies-COUNT(borrowed_book.b_id))+1,10)");
				}      		
	       
		}
		 catch(Exception e){}	
		 		System.out.println(Available);
		 return Available;
	}
	
	
	
	
	
	
	public void Search()
	{
		String b_n=SrcBookTF.getText();
	
		String columns[] = {"Book ID", "Book Name", "Available Copies"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(180,160,300,100);
		panel.add(tableScrollPane);

         String query = "SELECT `b_id`, `b_name` FROM `library`;";        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
                String Available ="";
                String b_id = rs.getString("b_id");
                String b_name = rs.getString("b_name");
				 //String s_id= rs.getString("s_id");
					Available=Avbl(b_id);
				
				if(b_name.contains(b_n))
					{
				
			tableModel.addRow(new Object[]{b_id, b_name, Available});
						break;			  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	
	
	
	
		public void actionPerformed(ActionEvent ae){
		
			String buttonClicked = ae.getActionCommand();
		if(buttonClicked.equals(back.getText()))
		{
			
			sh.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(SrcBookLabel.getText()))
		{
			//Library l=new Library(this);
			//l.setVisible(true);
			//this.setvisible(false);
		}
		else if(buttonClicked.equals(srch.getText()))
		{
			Search();
		}
		else{}
		
	}
}