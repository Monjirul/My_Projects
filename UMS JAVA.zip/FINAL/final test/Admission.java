import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

class Admission extends JFrame implements ActionListener, FocusListener
{
	private JLabel s_id, add_fee, h_reg, d_label, dept_id, imgLabel, s_pass;
	private JButton back, insert, delete, registered;
	private JPanel panel;
	private JTextField student_id, admission_fee, department_id, hsc_reg, student_pass;
	private String o_id, o_name, of_pass, a_id, od_id;
	private Random rand=new Random();
	private int r;
	private String F_name[]=new String[10],C_name[]=new String[10];
	private String F_id[]=new String[10],C_id[]=new String[10];
	private String F_fee[]=new String[10];
	private JComboBox combo, combo1, combo2;
	private ImageIcon img;
	private boolean hire_check=false;	
	
	public Admission(String o_id, String o_name, String od_id, String of_pass, String a_id)
	{
		super("Admission");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.a_id=a_id;
		

		panel = new JPanel();
		panel.setLayout(null);
		

		s_id = new JLabel("Student Id : ");  //registration welcome
		s_id.setBounds(10, 90, 150, 30);
		s_id.setForeground(Color.white);
		s_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(s_id);
		
		dept_id = new JLabel("Department : ");  //registration welcome
		dept_id.setBounds(10, 140, 150, 30);
		dept_id.setForeground(Color.white);
		dept_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(dept_id);
		
		h_reg = new JLabel("HSC Registration no : ");  //registration welcome
		h_reg.setBounds(10, 190, 250, 30);
		h_reg.setForeground(Color.white);
		h_reg.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(h_reg);
		
		s_pass = new JLabel("Student Pass :");  //registration welcome
		s_pass.setBounds(10, 240, 160, 30);
		s_pass.setForeground(Color.white);
		s_pass.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(s_pass);
		
		d_label = new JLabel("Delete with Student ID");  //registration welcome
		d_label.setBounds(430, 90, 300, 30);
		d_label.setForeground(Color.white);
		d_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(d_label);
			
		
	////////////////////////////////////////////////////////////////////////
	
		r=rand.nextInt(9999)+10000;
		student_id = new JTextField("S-"+r);  //exam_year
		student_id.setBounds(160, 90, 100, 25);
		student_id.addFocusListener(this);
		panel.add(student_id);
		
		
		//-------------------------------------------------------------------------------------
		
		
		String query2 = "SELECT `dept_id`, `d_name`, `add_fee` FROM `depertment`;";
		String q = "SELECT `s_id` FROM `addmission`;";
        try
		{
			int i=0;
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement st2 = con.createStatement();
			ResultSet rs2 = stm.executeQuery(q);
			ResultSet rs1 = st2.executeQuery(query2);
			
			while(rs1.next())
			{
				F_id [i]= rs1.getString("dept_id");
				F_name [i] = rs1.getString("d_name");
				F_fee [i] = rs1.getString("add_fee");
				i++;
			}
			
			
			while(rs2.next())
			{
				String O_id = rs2.getString("s_id");
				String temp="S-"+r;
				if(O_id==temp)
				{r=rand.nextInt(9999)+10000;student_id.setText("S-"+r);}
				else{student_id.setText("S-"+r);}
			}
			st2.close();
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		
		
		//-------------------------------------------------------------------------------------------
		
		combo = new JComboBox(F_name);
		combo.setBounds(160, 140, 100, 25);
		combo.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo);
		
		//-------------------------------------------------------------------------------------
		
		
		String query3 = "SELECT `c_id`, `c_name` FROM `course`;";
        try
		{
			int i=0;
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement st3 = con.createStatement();
			ResultSet rs3 = st3.executeQuery(query3);
			
			while(rs3.next())
			{
				C_id [i]= rs3.getString("c_id");
				C_name [i] = rs3.getString("c_name");
				i++;
			}
			
			st3.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		
		
		//-------------------------------------------------------------------------------------------
		
		combo1 = new JComboBox(C_name);
		combo1.setBounds(280, 140, 100, 25);
		combo1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		combo1.addActionListener(this);
		panel.add(combo1);
		
		String S_id[]={"A","B","C","D","E","F","G"};
		
		combo2 = new JComboBox(S_id);
		combo2.setBounds(400, 140, 40, 25);
		combo2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		combo2.addActionListener(this);
		panel.add(combo2);
		
		
		

		
		
		hsc_reg = new JTextField("HSC reg no");     //ssc_gpa
		hsc_reg.setBounds(250, 190, 100, 25);
		hsc_reg.addFocusListener(this);
		panel.add(hsc_reg);
		
		student_pass = new JTextField("Student pass");     //ssc_gpa
		student_pass.setBounds(170, 240, 100, 25);
		student_pass.addFocusListener(this);
		panel.add(student_pass);
		
		
		registered = new JButton("Showtable");
		registered.setBounds(570, 200, 150, 30);
		registered.addActionListener(this);
		panel.add(registered);
		
		insert = new JButton("Admit");
		insert.setBounds(150, 310, 150, 30);
		insert.addActionListener(this);
		panel.add(insert);
		
		delete = new JButton("Delete");
		delete.setBounds(270, 90, 150, 30);
		delete.addActionListener(this);
		panel.add(delete);
		
		back = new JButton("back");
		back.setBounds(570, 250, 150, 30);
		back.addActionListener(this);
		panel.add(back);
		
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		this.add(panel);
		
	}
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(student_id))
					{student_id.setText(""); hire_check=true; }
				else if(e.getSource().equals(hsc_reg))
					{hsc_reg.setText(""); hire_check=true; }
				else if(e.getSource().equals(student_pass))
					{student_pass.setText(""); hire_check=true; }
				else{}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(student_id)&&student_id.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Student Id");
					student_id.setText("S-"+r);hire_check=false;
				}
				else if(e.getSource().equals(hsc_reg)&&hsc_reg.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter HSC Reg. no.");
					hsc_reg.setText("HSC Reg. no.");hire_check=false;
				}
				else if(e.getSource().equals(student_pass)&&student_pass.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Student password");
					student_pass.setText("Student pass");hire_check=false;
				}
				else{}
		}
	
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			OfficerHome o = new OfficerHome(o_id,o_name,od_id,of_pass,a_id);
			o.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insert.getText()))
		{
			if(hire_check==true)
				{
					insertIntoDB1();
					insertIntoDB2();
					insertIntoDB3();
					hire_check=false;
					
				}
			else
				{JOptionPane.showMessageDialog(this,"Please fill all information");}
		}
		else if(buttonClicked.equals(delete.getText()))
		{
			delete_from_db();
		}
		else if(buttonClicked.equals(registered.getText()))
		{
			JtableAdmission r = new JtableAdmission(o_id, o_name, od_id, of_pass, a_id);
			r.setVisible(true);
			this.setVisible(false);
		}
		else{}
		
	}
	
	public void insertIntoDB1()
	{
		String temp=(String) combo.getSelectedItem();
		String t=null;
		int i=0;
		
		for(i=0;i<10;i++)
		{
			if(F_name[i]==temp)
			{temp=F_fee[i];t=F_id[i];System.out.println(temp);System.out.println(t);}
		}
		
		
		String query="INSERT INTO addmission VALUES ("+temp+",'"+student_id.getText()+"','"+hsc_reg.getText()+"','"+t+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void insertIntoDB2()
	{
		
		
		String query="INSERT INTO student VALUES ("+0.0+","+0+",'"+student_pass.getText()+"','"+student_id.getText()+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void insertIntoDB3()
	{
		String temp=(String) combo2.getSelectedItem();
		String t=(String) combo1.getSelectedItem();
		int i=0;
		
		for(i=0;i<10;i++)
		{
			if(C_name[i]==t)
			{t=C_id[i];System.out.println(t);}
		}
		
		String query="INSERT INTO s_course VALUES ('"+student_id.getText()+"','"+t+"-"+temp+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	
	public void delete_from_db()
	{
		String query1 = "DELETE from addmission where s_id='"+student_id.getText()+"';";
		String query2 = "DELETE from student where s_id='"+student_id.getText()+"';";
		String query3 = "DELETE from s_course where s_id='"+student_id.getText()+"';";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm3 = con.createStatement();
			Statement stm2 = con.createStatement();
			Statement stm1 = con.createStatement();
			stm3.execute(query3);
			stm2.execute(query2);
			stm1.execute(query1);
			stm3.close();
			stm2.close();
			stm1.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}