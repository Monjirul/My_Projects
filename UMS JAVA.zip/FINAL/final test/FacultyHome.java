import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

public class FacultyHome extends JFrame implements ActionListener
{
	private JLabel labelWelcome,labelAdId;
	private JButton addDrop, buttonLogout,TakeCourse,giveMarks;
	private JPanel panel;
	private String userId;
	private JLabel Ename,Eposition,Eid,Esal;
	private JButton Profile;
	String f_id, f_name, f_Pass;
	//double Emp_salary;
	String dept_id;
	String admin_id;
	public FacultyHome(String f_id,String f_name,String f_Pass,String dept_id,String admin_id)
	{
		super("Faculty Home Window");
		
		this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		 this.f_id=f_id;
		  this.f_name=f_name;
		   this.f_Pass=f_Pass;
		
		this.dept_id=dept_id;
         this.admin_id=admin_id;
		

	    
		labelWelcome = new JLabel("Logged In: "+f_name);
		labelWelcome.setBounds(120, 50, 200, 30);
		panel.add(labelWelcome);
		labelAdId = new JLabel("ID: "+f_id);
		labelAdId.setBounds(120, 100, 200, 30);
		panel.add(labelAdId);
		
		Profile = new JButton("Profile");
		Profile.setBounds(350, 50, 150, 30);
		Profile.addActionListener(this);
		panel.add(Profile);
		
		
		TakeCourse = new JButton("Take Courses");
		TakeCourse.setBounds(120, 250, 150, 30);
		TakeCourse.addActionListener(this);
		panel.add(TakeCourse);
		
		
		addDrop = new JButton("Add/Drop Students from class");
		addDrop.setBounds(50, 200, 250, 30);
		addDrop.addActionListener(this);
		panel.add(addDrop);
		
	
		giveMarks = new JButton("Addmission Marks");
		giveMarks.setBounds(50, 300, 250, 30);
		giveMarks.addActionListener(this);
		panel.add(giveMarks);
	
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(350, 200, 150, 30);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		
		
		this.add(panel);
		this.userId=userId;
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
	if(buttonClicked.equals(Profile.getText()))
		{
			FacultyProfile ap= new FacultyProfile(f_id,f_name,f_Pass,dept_id,admin_id);
		ap.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(buttonLogout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}
	else if(buttonClicked.equals(addDrop.getText()))
		{
			AddDropStudent l = new AddDropStudent(this);
			l.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(TakeCourse.getText()))
		{
			TakeCourse tc = new TakeCourse(f_id,f_name,f_Pass,dept_id,admin_id);
			tc.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(giveMarks.getText()))
		{
			Ad_marks adm = new Ad_marks(this);
			adm.setVisible(true);
			this.setVisible(false);
			
		}
		else{}
	}
}



