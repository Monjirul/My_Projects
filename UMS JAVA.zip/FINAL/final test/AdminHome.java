import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

public class AdminHome extends JFrame implements ActionListener
{
	private JLabel admin_welcome, admin_name, admin_id, imgLabel;
	private JButton add_officer, add_faculty, logout, profile, add_department;
	private JPanel panel;
	private String a_name, a_id, a_pass;
	private ImageIcon img;
	

	public AdminHome(String a_name,String a_id,String a_pass)
	{
		super("Admin Home");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		this.a_name=a_name;
		this.a_id=a_id;
		this.a_pass=a_pass;

		
		
		admin_name = new JLabel("Admin Name : "+a_name);  //Admin name
		admin_name.setForeground(Color.white);
		admin_name.setBounds(20, 130, 200, 30);
		admin_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(admin_name);
		
		admin_id = new JLabel("Admin ID : "+a_id);    //Admin id
		admin_id.setForeground(Color.white);
		admin_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		admin_id.setBounds(20, 180, 200, 30);
		panel.add(admin_id);
		
		profile = new JButton("Profile");    //profile button
		profile.setBounds(20, 300, 150, 50);
		profile.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		profile.addActionListener(this);
		panel.add(profile);
		
		logout = new JButton("Logout");     //logout
		logout.setBounds(190, 300, 150, 50);
		logout.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		logout.addActionListener(this);
		panel.add(logout);
		
		
		add_officer = new JButton("Add Officer");  //add_officer 
		add_officer.setBounds(500, 150, 200, 60);
		add_officer.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		add_officer.addActionListener(this);
		panel.add(add_officer);
		
		add_faculty = new JButton("Add Faculty");   //add_faculty
		add_faculty.setBounds(500, 230, 200, 60);
		add_faculty.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		add_faculty.addActionListener(this);
		panel.add(add_faculty);
		
		add_department = new JButton("Add Department");   //add_department
		add_department.setBounds(500, 310, 200, 60);
		add_department.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		add_department.addActionListener(this);
		panel.add(add_department);
		
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		

		this.add(panel);
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(add_faculty.getText()))
		{
			AddFaculty af = new AddFaculty(a_name,a_id,a_pass);
			af.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(add_officer.getText()))
		{
			AddOfficers ao = new AddOfficers(a_name,a_id,a_pass);
			ao.setVisible(true);
			this.setVisible(false);
		}
       else if(buttonClicked.equals(profile.getText()))
		{
			AdminProfile ap= new AdminProfile(a_name,a_id,a_pass);
			ap.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(logout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(add_department.getText()))
		{
			AddDepartment a = new AddDepartment(a_name,a_id,a_pass);
			a.setVisible(true);
			this.setVisible(false);
		}
	}
}