import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener, FocusListener
{
	private JLabel nameLabel, passLabel, imgLabel;
	private JTextField userNameTF;
	private JPasswordField passPF;
	private JButton buttonLogin, buttonClose;
	private JPanel panel;
	private boolean flag=false, f_adm=false, f_off=false, f_fac=false, f_stu=false;
	private ImageIcon img;	
	private boolean hire_check=false;
	
	
	public Login()
	{
		super("University Login");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		nameLabel = new JLabel(" Id :");
		nameLabel.setBounds(220, 170, 100, 30);
		nameLabel.setForeground(Color.white);
		nameLabel.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,25));
		panel.add(nameLabel);
		
		userNameTF = new JTextField("Enter your ID");
		userNameTF.setBounds(320, 170, 150, 30);
		userNameTF.addFocusListener(this);
		panel.add(userNameTF);
		
		passLabel = new JLabel("Password : ");
		passLabel.setBounds(150, 220, 160, 30);
		passLabel.setForeground(Color.white);
		passLabel.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,25));
		panel.add(passLabel);
		
		passPF = new JPasswordField("");
		passPF.setBounds(320, 220, 150, 25);
		passPF.addFocusListener(this);
		panel.add(passPF);
		
		buttonLogin = new JButton("Login");
		buttonLogin.setBounds(320,280,150,40);
		buttonLogin.addActionListener(this);
		panel.add(buttonLogin);
		
		buttonClose = new JButton("Close");
		buttonClose.setBounds(670,350,80,40);
		buttonClose.addActionListener(this);
		panel.add(buttonClose);
		
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		this.add(panel);
	}
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(userNameTF))
					{userNameTF.setText("");hire_check=true; }
				else if(e.getSource().equals(passPF))
					{passPF.setText(""); hire_check=true; }
				else{}
			}
	

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(userNameTF)&&userNameTF.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter your ID");
					userNameTF.setText("Enter your ID");hire_check=false;
				}
				if(e.getSource().equals(passPF)&&passPF.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter your password");
					passPF.setText("");hire_check=false;
				}
				else{}
		}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(buttonLogin.getText()))
		{
		
			String WhichUser= userNameTF.getText();
			char ch=WhichUser.charAt(0);
			
			if(hire_check==true)
				{
					hire_check=false;
					if(ch=='F')
						{
							check_fac();
						}
					else if(ch=='O')
						{
							check_off();
						}
					else if(ch=='A')
						{
							check_admin();
						}
					else if(ch=='S')
						{
							check_stu();
						}
					else
						{
							JOptionPane.showMessageDialog(this,"Not A USER");
						}
				}
			else{JOptionPane.showMessageDialog(this,"PLease enter required information");}
		}
		else if(buttonClicked.equals(buttonClose.getText()))
		{
			System.exit(0);
		}
		else{}
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////
	
	public void check_stu()
	{
        String query = "SELECT `cgpa`, `credits`, `s_pass`, `s_id` FROM `student`;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
				double Cgpa =Double.parseDouble(rs.getString("cgpa"));
				int Credit = Integer.parseInt(rs.getString("credits"));
                String S_pass = rs.getString("s_pass");			
			    String S_id = rs.getString("s_id");

				
				if(S_id.equals(userNameTF.getText()))
					{
						f_stu=true;
						flag=true;
						if(S_pass.equals(passPF.getText()))
							{
								
								StudentHome ush = new StudentHome(Cgpa,Credit,S_pass,S_id);
								this.setVisible(false);
								ush.setVisible(true);
								flag=false;
							}
					}
			}	
			if(f_stu==false){JOptionPane.showMessageDialog(this,"Wrong ID");}
			if(flag==true){JOptionPane.showMessageDialog(this,"Wrong password");flag=false;}
		}
        catch(Exception ex)
			{
				System.out.println("Exception : " +ex.getMessage());
			}
        finally
			{
				try
				{
					if(rs!=null)
						rs.close();
					if(st!=null)
						st.close();
					if(con!=null)
						con.close();
				}
				catch(Exception ex){}
			}
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////
	
	
	public void check_admin()
	{
        String query = "SELECT `admin_name`, `admin_Id`, `ad_Pass` FROM `administrator`;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
               
     			 String Admin_name = rs.getString("admin_name");
				 String Admin_Id = rs.getString("admin_Id");
	             String Ad_Pass = rs.getString("ad_Pass");              
			
				
				if(Admin_Id.equals(userNameTF.getText()))
				{
					f_adm=true;
					flag=true;
					if(Ad_Pass.equals(passPF.getText()))
					{
							AdminHome adh = new AdminHome(Admin_name,Admin_Id,Ad_Pass);
							this.setVisible(false);
							adh.setVisible(true);
							flag=false;
					}
				}
			}
			if(f_adm==false){JOptionPane.showMessageDialog(this,"Wrong ID");}
				if(flag==true){JOptionPane.showMessageDialog(this,"Wrong password");flag=false;}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();
                if(st!=null)
					st.close();
                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
    }
	
	
      //////////////////////////////////////////////////////////////////////////////////////////////officer check


	public void check_off()
	{
        String query = "SELECT `o_id`, `o_name`, `o_pass`, `od_id`, `Admin_Id` FROM `oficers`;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
	
			while(rs.next())
			{
                String O_id = rs.getString("o_id");
				String O_name = rs.getString("o_name");
				String Od_id = rs.getString("od_id");	
				String Of_Pass = rs.getString("o_pass");
				String Admin_Id = rs.getString("Admin_Id");
				
				if(O_id.equals(userNameTF.getText()))
				{
					f_off=true;
					flag=true;
					if(Of_Pass.equals(passPF.getText()))
					{
							OfficerHome o = new OfficerHome(O_id,O_name,Od_id,Of_Pass,Admin_Id);
							o.setVisible(true);
							this.setVisible(false);
							flag=false;
					}
				}
			}
			if(f_off==false){JOptionPane.showMessageDialog(this,"Wrong ID");}
			if(flag==true){JOptionPane.showMessageDialog(this,"Wrong password");flag=false;}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();
                if(st!=null)
					st.close();
                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
    } 
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////faculty check
	
	
	public void check_fac()
	{
        String query = "SELECT `f_id`, `f_name`, `f_pass`, `dept_id`, `admin_Id` FROM `faculties`;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result

			while(rs.next())
			{
                String F_id = rs.getString("f_id");
				String F_name = rs.getString("f_name");
				String F_Pass = rs.getString("f_pass");
				String dept_id = rs.getString("dept_id");
				String Admin_Id = rs.getString("admin_Id");
				
				
				if(F_id.equals(userNameTF.getText()))
				{
					f_fac=true;
					flag=true;
					if(F_Pass.equals(passPF.getText()))
					{
						
							FacultyHome ush = new FacultyHome(F_id,F_name,F_Pass,dept_id,Admin_Id);
							this.setVisible(false);
							ush.setVisible(true);
							flag=false;
					}
				}
			}
			if(f_fac==false){JOptionPane.showMessageDialog(this,"Wrong ID");}
			if(flag==true){JOptionPane.showMessageDialog(this,"Wrong password");flag=false;}	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();
                if(st!=null)
					st.close();
                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
    } 
	
	
}
