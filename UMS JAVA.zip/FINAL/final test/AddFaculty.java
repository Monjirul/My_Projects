import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

class AddFaculty extends JFrame implements ActionListener, FocusListener
{
	private JLabel f_name, f_id, f_pass, dept_id, d_label, f_sal, imgLabel;
	private JButton back, insert, delete, registered;
	private JPanel panel;
	private JTextField faculty_id, faculty_name, faculty_pass, department_id, faculty_sal;
	private String a_id, a_name, a_pass;
	private JComboBox combo;
	private Random rand=new Random();
	private int r;
	private String F_name[]=new String[10];
	private String F_id[]=new String[10];
	private ImageIcon img;
	private boolean hire_check=false;	
	
	
	public AddFaculty( String a_name ,String a_id, String a_pass)
	{
		super("Faculty Registration");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.a_id=a_id;
		this.a_name=a_name;
		this.a_pass=a_pass;
		

		panel = new JPanel();
		panel.setLayout(null);
		
		f_name = new JLabel("Faculty Name : ");  //registration welcome
		f_name.setBounds(20, 110, 200, 30);
		f_name.setForeground(Color.white);
		f_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(f_name);
		
		f_id = new JLabel("Faculty ID : ");  //registration welcome
		f_id.setBounds(20, 150, 200, 30);
		f_id.setForeground(Color.white);
		f_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(f_id);
		
		f_pass = new JLabel("Faculty Password : ");  //registration welcome
		f_pass.setBounds(20, 190, 200, 30);
		f_pass.setForeground(Color.white);
		f_pass.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(f_pass);
		
		dept_id = new JLabel("Department ID : ");  //registration welcome
		dept_id.setBounds(20, 230, 200, 30);
		dept_id.setForeground(Color.white);
		dept_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(dept_id);
		
		f_sal = new JLabel("Faculty Salary : ");  //registration welcome
		f_sal.setBounds(20, 270, 200, 30);
		f_sal.setForeground(Color.white);
		f_sal.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(f_sal);
		
		d_label = new JLabel("Delete with Faculty ID");  //registration welcome
		d_label.setBounds(440, 150, 350, 30);
		d_label.setForeground(Color.white);
		d_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(d_label);
			
		
	////////////////////////////////////////////////////////////////////////

	r=rand.nextInt(999)+6000;
	
		faculty_name = new JTextField("Faculty name");  
		faculty_name.setBounds(220, 110, 150, 25);
		faculty_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		faculty_name.addFocusListener(this);
		panel.add(faculty_name);
		
		faculty_id = new JTextField("F-"+r); 
		faculty_id.setBounds(220, 150, 100, 25);
		faculty_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		faculty_id.addFocusListener(this);
		panel.add(faculty_id);
		
		faculty_pass = new JTextField("Faculty Pass");   
		faculty_pass.setBounds(220, 190, 100, 25);
		faculty_pass.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		faculty_pass.addFocusListener(this);
		panel.add(faculty_pass);
		
		//-------------------------------------------------------------------------------------
		
		

		String q = "SELECT `dept_id`, `d_name` FROM `depertment`;";
		String query2 = "SELECT `f_id` FROM `faculties`;";
        try
		{
			int i=0;
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement st2 = con.createStatement();
			ResultSet rs1 = stm.executeQuery(q);
			ResultSet rs2 = st2.executeQuery(query2);
			
			while(rs1.next())
			{
				F_id [i]= rs1.getString("dept_id");
				F_name [i] = rs1.getString("d_name");
				i++;
			}
			while(rs2.next())
			{
				String O_id = rs2.getString("f_id");
				String temp="F-"+r;
				if(O_id==temp)
				{r=rand.nextInt(999)+6000;faculty_id.setText("F-"+r);}
				else{faculty_id.setText("F-"+r);}
			}
			st2.close();
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		
		
		//-------------------------------------------------------------------------------------------
		
		
		
		//String s[] = {"CSE", "CS", "CSSE", "SE", "CIS"};
		combo = new JComboBox(F_name);
		combo.setBounds(220, 230, 120, 25);
		combo.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo);	
		
		
		faculty_sal = new JTextField("Faculty Salary");  
		faculty_sal.setBounds(220, 270, 120, 25);
		faculty_sal.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		faculty_sal.addFocusListener(this);
		panel.add(faculty_sal);

		
		registered = new JButton("Showtable");
		registered.setBounds(500, 270, 200, 50);
		registered.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		registered.addActionListener(this);
		panel.add(registered);
		
		insert = new JButton("Hire");
		insert.setBounds(220, 340, 150, 30);
		insert.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		insert.addActionListener(this);
		panel.add(insert);
		
		delete = new JButton("Delete");
		delete.setBounds(330, 150, 100, 30);
		delete.addActionListener(this);
		panel.add(delete);
		
		back = new JButton("Back");
		back.setBounds(500, 340, 200, 50);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
		
	}
	
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(faculty_name))
					{faculty_name.setText(""); hire_check=true; }
				else if(e.getSource().equals(faculty_id))
					{faculty_id.setText(""); hire_check=true; }
				else if(e.getSource().equals(faculty_pass))
					{faculty_pass.setText(""); hire_check=true;}
				else if(e.getSource().equals(faculty_sal))
					{faculty_sal.setText("");hire_check=true;}
				else{}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(faculty_name)&&faculty_name.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Faculty name");
					faculty_name.setText("Faculty name");hire_check=false;
				}
				else if(e.getSource().equals(faculty_id)&&faculty_id.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Faculty Id");
					faculty_id.setText("F-"+r);hire_check=false;
				}
				else if(e.getSource().equals(faculty_pass)&&faculty_pass.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Faculty password");
					faculty_pass.setText("Faculty Pass");hire_check=false;
				}
				else if(e.getSource().equals(faculty_sal)&&faculty_sal.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Faculty salary");
					faculty_sal.setText("Faculty Salary");hire_check=false;
				}
				else{}
		}
	
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			AdminHome a= new AdminHome(a_name,a_id,a_pass);
			a.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insert.getText()))
		{
			if(hire_check==true)
				{insertIntoDB();hire_check=false;}
			else
				{JOptionPane.showMessageDialog(this,"Please fill all information");}
		}
		else if(buttonClicked.equals(delete.getText()))
		{
			delete_from_db();
		}
		else if(buttonClicked.equals(registered.getText()))
		{
			Registeredfaculty rf = new Registeredfaculty(a_name,a_id,a_pass);
			rf.setVisible(true);
			this.setVisible(false);
		}
		
	}
	
	public void insertIntoDB()
	{
		String temp=(String) combo.getSelectedItem();
		int i=0;
		
		for(i=0;i<10;i++)
		{
			if(F_name[i]==temp)
			{temp=F_id[i];System.out.println(temp);System.out.println(faculty_id.getText());}
		}
		
		String query="INSERT INTO faculties VALUES ('"+faculty_id.getText()+"','"+faculty_name.getText()+"','"+faculty_pass.getText()+"','"+temp+"','"+a_id+"');";
		String q="INSERT INTO faculty_salary VALUES ("+faculty_sal.getText()+",'"+"F-"+r+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement s= con.createStatement();
			stm.execute(query);
			s.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void delete_from_db()
	{
		String query = "DELETE from faculties where f_id='"+faculty_id.getText()+"';";
		String q="DELETE from faculty_salary where f_id='"+faculty_id.getText()+"';";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement s= con.createStatement();
			s.execute(q);
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}