import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

class RegPage extends JFrame implements ActionListener, FocusListener
{
	private JLabel reg_welcome, e_year, e_semester, h_reg, h_gpa, s_gpa, d_id, d_label, ol_id, s_name, imgLabel;
	private JButton back, insert, delete, registered;
	private JPanel panel;
	private JTextField exam_year, exam_semester, r_name, hsc_reg, hsc_gpa, ssc_gpa, department_id, student_name, officer_id;
	private String o_id, o_name, of_pass, a_id, od_id;
	private Random rand=new Random();
	private int r;
	private JComboBox combo1, combo2;
	private ImageIcon img;
	private boolean hire_check=false;	
	
	
	public RegPage(String o_id, String o_name, String od_id, String of_pass, String a_id)
	{
		super("Registration page");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.a_id=a_id;
		

		panel = new JPanel();
		panel.setLayout(null);
		
		e_year = new JLabel("Exam Year : ");  //registration welcome
		e_year.setBounds(10, 80, 150, 30);
		e_year.setForeground(Color.white);
		e_year.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(e_year);
		
		e_semester = new JLabel("Exam Semester : ");  //registration welcome
		e_semester.setBounds(10, 130, 150, 30);
		e_semester.setForeground(Color.white);
		e_semester.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(e_semester);
		
		h_reg = new JLabel("HSC Registration no : ");  //registration welcome
		h_reg.setBounds(10, 180, 200, 30);
		h_reg.setForeground(Color.white);
		h_reg.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(h_reg);
		
		h_gpa = new JLabel("HSC GPA : ");  //registration welcome
		h_gpa.setBounds(10, 230, 150, 30);
		h_gpa.setForeground(Color.white);
		h_gpa.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(h_gpa);
		
		s_gpa = new JLabel("SSC GPA : ");  //registration welcome
		s_gpa.setBounds(10, 280, 150, 30);
		s_gpa.setForeground(Color.white);
		s_gpa.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(s_gpa);
		
		s_name = new JLabel("Student name : ");  //registration welcome
		s_name.setBounds(10, 330, 150, 30);
		s_name.setForeground(Color.white);
		s_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(s_name);
		
		d_label = new JLabel("Delete with HSC Reg no.");  //registration welcome
		d_label.setBounds(480, 180, 250, 30);
		d_label.setForeground(Color.white);
		d_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,17));
		panel.add(d_label);
		
	////////////////////////////////////////////////////////////////////////
	
		String s1[] = {"2017", "2018", "2019", "2020", "2021"};
		combo1 = new JComboBox(s1);
		combo1.setBounds(160, 80, 100, 25);
		combo1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo1);
		
		
		String s2[] = {"Summer", "Spring", "Fall"};
		combo2 = new JComboBox(s2);
		combo2.setBounds(160, 130, 100, 25);
		combo2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo2);
		
		hsc_reg = new JTextField("HCS Reg. no.");  //hsc_reg
		hsc_reg.setBounds(210, 180, 100, 25);
		hsc_reg.addFocusListener(this);
		panel.add(hsc_reg);
		
		hsc_gpa = new JTextField("hsc_gpa");  //hsc_gpa
		hsc_gpa.setBounds(160, 230, 100, 25);
		hsc_gpa.addFocusListener(this);
		panel.add(hsc_gpa);
		
		ssc_gpa = new JTextField("SSC gpa");     //ssc_gpa
		ssc_gpa.setBounds(160, 280, 100, 25);
		ssc_gpa.addFocusListener(this);
		panel.add(ssc_gpa);
		
		student_name = new JTextField("student_name"); //department_id
		student_name.setBounds(160, 330, 200, 25);
		student_name.addFocusListener(this);
		panel.add(student_name);
		
		registered = new JButton("Showtable");
		registered.setBounds(520, 330, 150, 30);
		registered.addActionListener(this);
		panel.add(registered);
		
		insert = new JButton("Insert");
		insert.setBounds(150, 380, 150, 30);
		insert.addActionListener(this);
		panel.add(insert);
		
		delete = new JButton("Delete");
		delete.setBounds(320, 180, 150, 30);
		delete.addActionListener(this);
		panel.add(delete);
		
		back = new JButton("back");
		back.setBounds(520, 380, 150, 30);
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		this.add(panel);
		
	}
	
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(hsc_reg))
					{hsc_reg.setText(""); hire_check=true; }
				else if(e.getSource().equals(hsc_gpa))
					{hsc_gpa.setText(""); hire_check=true; }
				else if(e.getSource().equals(ssc_gpa))
					{ssc_gpa.setText(""); hire_check=true;}
				else if(e.getSource().equals(student_name))
					{student_name.setText("");hire_check=true;}
				else{}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(hsc_reg)&&hsc_reg.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Hsc Reg. no.");
					hsc_reg.setText("HSC Reg. no.");hire_check=false;
				}
				else if(e.getSource().equals(hsc_gpa)&&hsc_gpa.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter HSC gpa");
					hsc_gpa.setText("hsc_gpa");hire_check=false;
				}
				else if(e.getSource().equals(ssc_gpa)&&ssc_gpa.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter SSC gpa");
					ssc_gpa.setText("SSC gpa");hire_check=false;
				}
				else if(e.getSource().equals(student_name)&&student_name.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter Student name");
					student_name.setText("student_name");hire_check=false;
				}
				else{}
		}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			OfficerHome o = new OfficerHome(o_id,o_name,od_id,of_pass,a_id);
			o.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insert.getText()))
		{
			if(hire_check==true)
				{insertIntoDB();hire_check=false;}
			else
				{JOptionPane.showMessageDialog(this,"Please fill all information");}
		}
		else if(buttonClicked.equals(delete.getText()))
		{
			delete_from_db();
		}
		else if(buttonClicked.equals(registered.getText()))
		{
			JtableRegPage r = new JtableRegPage(o_id, o_name, od_id, of_pass, a_id);
			r.setVisible(true);
			this.setVisible(false);
		}
		
	}
	
	public void insertIntoDB()
	{
		String a=(String) combo1.getSelectedItem();
		String b=(String) combo2.getSelectedItem();
		
		String query="INSERT INTO regestration VALUES ('"+a+"','"+b+"','"+hsc_reg.getText()+"',"+ssc_gpa.getText()+","+hsc_gpa.getText()+",'"+student_name.getText()+"','"+o_id+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void delete_from_db()
	{
		String query = "DELETE from regestration where hsc_reg_no="+hsc_reg.getText()+";";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();
					
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}