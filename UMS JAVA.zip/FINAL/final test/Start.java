public class Start
{
	public static void main(String args[])
	{
		Login l = new Login();
		l.setVisible(true);
	}
}