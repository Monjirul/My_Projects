import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.io.*;
public class StudentProfile extends JFrame implements ActionListener,MouseListener
{
	public StudentHome sh;
	private JLabel labelWelcome, labelName, labelID, labelcgpa,labeldept,labelcredit,labelPrevPass,labelNewPass,labelConfPass;
	private JButton buttonLogout, buttonChangePassword,buttonBack,ShowPass;
	private JPanel panel;
	private JPasswordField  OldpassPF, NewpassPF,ConfirmpassPF;
	String s_id,s_pass;
	int cpf=0;
	public StudentProfile(double cgpa,int credits,String s_Pass,String s_id,String name,String d_name,StudentHome sh)
	{
		super("Student PROFILE");
		
		this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		s_Pass=s_Pass;
		this.s_id=s_id;
		
		panel = new JPanel();
		panel.setLayout(null);
		this.sh=sh;
		labelWelcome = new JLabel("Student Account");
		labelWelcome.setBounds(200, 0, 200, 30);
		panel.add(labelWelcome);
		
		labelName = new JLabel("Name	:	"+name);
		labelName.setBounds(200, 50, 200, 30);
		panel.add(labelName);
		
		labelID = new JLabel("ID	:	"+s_id);
		labelID.setBounds(200, 100, 200, 30);
		panel.add(labelID);
	
		labelcgpa = new JLabel("CGPA	:	"+cgpa);
		labelcgpa.setBounds(200, 150, 200, 30);
		panel.add(labelcgpa);

		labelcredit = new JLabel("Credits Completed	:	"+credits);
		labelcredit.setBounds(200, 200, 200, 30);
		panel.add(labelcredit);		
			

	    labeldept = new JLabel("DEPARTMENT	:	"+d_name);
		labeldept.setBounds(200, 250, 200, 30);
		panel.add(labeldept);		
		
		
		buttonChangePassword = new JButton("Change Password");
		buttonChangePassword.setBounds(150, 300, 150, 30);
		buttonChangePassword.addActionListener(this);
		panel.add(buttonChangePassword);
		
				ShowPass = new JButton("Show Password");
		ShowPass.setBounds(600, 500, 150, 30);
		ShowPass.addActionListener(this);
		ShowPass.addMouseListener(this);
		panel.add(ShowPass);
		ShowPass.setVisible(false);
		
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(450, 0, 150, 30);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);


		buttonBack = new JButton("Back");
		buttonBack.setBounds(0, 0, 150, 30);
		buttonBack.addActionListener(this);
		panel.add(buttonBack);

		
		labelPrevPass = new JLabel("Confirm Old Password:");
		labelPrevPass.setBounds(200, 300, 200, 30);
		panel.add(labelPrevPass);
		this.add(panel);
		
				OldpassPF = new JPasswordField();
		OldpassPF.setBounds(400, 300, 200, 30);
		panel.add(OldpassPF);
		
				labelNewPass = new JLabel("New Password:");
		labelNewPass.setBounds(200, 350, 200, 30);
		panel.add(labelNewPass);
		this.add(panel);
		
					NewpassPF = new JPasswordField();
		NewpassPF.setBounds(400, 350, 200, 30);
		panel.add(NewpassPF);
		
				labelConfPass = new JLabel("Confirm New Password:");
		labelConfPass.setBounds(200, 400, 200, 30);
		panel.add(labelConfPass);
	
			ConfirmpassPF = new JPasswordField();
		ConfirmpassPF.setBounds(400, 400, 200, 30);
		panel.add(ConfirmpassPF);
labelPrevPass.setVisible(false);OldpassPF.setVisible(false);labelNewPass.setVisible(false);
NewpassPF.setVisible(false);ConfirmpassPF.setVisible(false);labelConfPass.setVisible(false);

	this.add(panel);
	
	
	
	}
	public void actionPerformed(ActionEvent ae){
		
			String buttonClicked = ae.getActionCommand();
		  if(buttonClicked.equals(buttonBack.getText()))
		{
			//Login l = new Login();
			sh.setVisible(true);
			this.setVisible(false);
		}
		 else if(buttonClicked.equals(buttonLogout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}

		else if(buttonClicked.equals(buttonChangePassword.getText()))
		{
          if(cpf==0)	
        {	
        cpf=1;
			buttonChangePassword.setBounds(150, 500, 150, 30);
			buttonChangePassword.setText("Confirm Password");
      labelPrevPass.setVisible(true);OldpassPF.setVisible(true);
	  labelNewPass.setVisible(true);
      NewpassPF.setVisible(true);ConfirmpassPF.setVisible(true);labelConfPass.setVisible(true);
			ShowPass.setVisible(true);

	}
	else if(cpf==1)
	{
	

String sid=s_id;
//query = "update oficers set o_pass='"+password_field.getText()+"' where o_id='"+o_id+"'";


	String query2 = "update student set s_pass='"+ConfirmpassPF.getText()+"' where s_id='"+s_id+"'";
	String query1="SELECT `s_pass`,`cgpa` FROM `student` where s_id='"+sid+"';";
			Connection con=null;//for connection
			Statement st = null;//for query execution
			ResultSet rs = null;//to get row by row result from DB
			try
			{
				Class.forName("com.mysql.jdbc.Driver");//load driver
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
				st = con.createStatement();//create statement
				rs = st.executeQuery(query1);//getting result
				System.out.println("res paisi");
				while(rs.next())
					{
						//double cgpa=rs.getDouble("cgpa");
				String s_pass=rs.getString("s_pass");
				//System.out.println("res paisi");
				System.out.println(s_pass);
				//System.out.println("cg "+cgpa);
				System.out.println("pass "+OldpassPF.getText());
				if(s_pass.equals(OldpassPF.getText()))
				{
					String passfield=ConfirmpassPF.getText();
					//System.out.println(passfield);
					//System.out.println("res milse");
					
					if((ConfirmpassPF.getText().equals(NewpassPF.getText())) && passfield.length()>2)
					{
						//System.out.println("pass changed");
							cpf=0;				
				st.executeUpdate(query2);
				st.close();
				con.close();
				rs.close();
				break;
					}
					
						else{JOptionPane.showMessageDialog(this,"Length not less than Three");}
				
					
				}
				else{JOptionPane.showMessageDialog(this,"Wrong Password");}
					}
				}			
			
             catch(Exception e){}
	
	}
	}
		else{}
	}
	
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	public void mouseClicked(MouseEvent me){}
	public void mouseReleased(MouseEvent me)
	{
		if(me.getSource().equals(ShowPass))
		{
			OldpassPF.setEchoChar('*');
			 NewpassPF.setEchoChar('*');
			 ConfirmpassPF.setEchoChar('*');
			//pf.setEchoChar('*');
		}
	}
	public void mousePressed(MouseEvent me)
	{
		if(me.getSource().equals(ShowPass))
		{
	OldpassPF.setEchoChar((char)0);
			 NewpassPF.setEchoChar((char)0);
			 ConfirmpassPF.setEchoChar((char)0);	
		//pf.setEchoChar((char)0);
		}
	}
}


