import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class AddDropStudent extends JFrame implements ActionListener
{
	private JLabel S_id , C_id, d_label, s_name;
	private JButton back, insert, delete, viewStd;
	private JPanel panel;
	private JTextField sid, class_id;
	private String a_id, a_name, a_pass;
	String f_id, f_name, f_Pass;
	//double Emp_salary;
	String dept_id;
	String admin_id;
	
	FacultyHome fh;
	
	public AddDropStudent(FacultyHome fh)
	{
		super("Add Drop Student");
		
		this.setSize(600, 350);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		panel = new JPanel();
		panel.setLayout(null);
		
		S_id = new JLabel("Student ID : ");  //registration welcome
		S_id.setBounds(10, 50, 100, 30);
		panel.add(S_id);
		
		C_id = new JLabel("Class ID : ");  //registration welcome
		C_id.setBounds(10, 10, 100, 30);
		panel.add(C_id);
		
				
        this.fh=fh;
			
		
	////////////////////////////////////////////////////////////////////////

		sid = new JTextField();  
		sid.setBounds(120, 50, 150, 25);
		panel.add(sid);
		
		class_id = new JTextField(); 
		class_id.setBounds(120, 10, 100, 25);
		panel.add(class_id);
		
		

		
		insert = new JButton("ADD");
		insert.setBounds(80, 200, 160, 30);
		insert.addActionListener(this);
		panel.add(insert);
		
		delete = new JButton("DROP");
		delete.setBounds(280, 200, 160, 30);
		delete.addActionListener(this);
		panel.add(delete);
		
		back = new JButton("Back");
		back.setBounds(370, 250, 160, 30);
		back.addActionListener(this);
		panel.add(back);
		
		viewStd = new JButton("View Students");
		viewStd.setBounds(280, 50, 160, 30);
		viewStd.addActionListener(this);
		panel.add(viewStd);
		
		this.add(panel);
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			fh.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insert.getText()))
		{
			insertIntoDB();
		}
		else if(buttonClicked.equals(delete.getText()))
		{
			delete_from_db();
		}
		else if(buttonClicked.equals(viewStd.getText()))
		{
			viewCourseStd vcs= new viewCourseStd(this);
			vcs.setVisible(true);
			this.setVisible(false);
		}
			
	}
	
	public void insertIntoDB()
	{
		String q="INSERT INTO s_course VALUES ('"+sid.getText()+"','"+class_id.getText()+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void delete_from_db()
	{
		String q="DELETE from s_course where s_id='"+sid.getText()+"' and class_id='"+class_id.getText()+"';";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}