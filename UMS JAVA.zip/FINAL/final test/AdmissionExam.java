import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class AdmissionExam extends JFrame implements ActionListener, FocusListener
{
	private JLabel e_date, e_time, e_room, e_mark, h_reg, d_label, exam_mark_label, imgLabel;
	private JButton back, insert, delete, registered;
	private JPanel panel;
	private JTextField exam_date, exam_time, exam_room, exam_mark, hsc_reg;
	private String o_id, o_name, of_pass, a_id, od_id, Marks;
	private JComboBox combo1, combo2, combo3, combo4;
	private ImageIcon img;
	private boolean hire_check=false;	
	
	public AdmissionExam(String o_id, String o_name, String od_id, String of_pass, String a_id)
	{
		super("AdmissionExam");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.a_id=a_id;
		

		panel = new JPanel();
		panel.setLayout(null);
		
		String date[]=new String[31];
		String month[]=new String[12];
		String year[]={"2017", "2018", "2019", "2020", "2021"};
		String time[] = {"9:30 am", "12:00 pm", "3:00 pm"};
		
		
		int d=0, m=0, i=0;
		for(i=0;i<31;i++)
		{
			d=d+1;
			date[i]=Integer.toString(d);
			if(i<12){m=m+1;month[i]=Integer.toString(m);}
		}
		

		e_date = new JLabel("Exam Date : ");  //registration welcome
		e_date.setBounds(10, 60, 150, 30);
		e_date.setForeground(Color.white);
		e_date.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(e_date);
		
		e_time = new JLabel("Exam Time : ");  //registration welcome
		e_time.setBounds(10, 110, 150, 30);
		e_time.setForeground(Color.white);
		e_time.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(e_time);
		
		h_reg = new JLabel("HSC Reg. no. : ");  //registration welcome
		h_reg.setBounds(10, 160, 180, 30);
		h_reg.setForeground(Color.white);
		h_reg.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(h_reg);
		
		d_label = new JLabel("Delete with HSC Reg no.");  //registration welcome
		d_label.setBounds(430, 160, 300, 30);
		d_label.setForeground(Color.white);
		d_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(d_label);

		
	////////////////////////////////////////////////////////////////////////

		combo1 = new JComboBox(date);
		combo1.setBounds(160, 60, 50, 25);
		combo1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo1);
		
		combo2 = new JComboBox(month);
		combo2.setBounds(220, 60, 50, 25);
		combo2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo2);
		
		combo3 = new JComboBox(year);
		combo3.setBounds(280, 60, 60, 25);
		combo3.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo3);
		
		combo4 = new JComboBox(time);
		combo4.setBounds(160, 110, 80, 25);
		combo4.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo4);
		
		hsc_reg = new JTextField("HSC reg no");     //ssc_gpa
		hsc_reg.setBounds(180, 160, 100, 25);
		hsc_reg.addFocusListener(this);
		panel.add(hsc_reg);
		
		
		registered = new JButton("Showtable");
		registered.setBounds(570, 250, 150, 30);
		registered.addActionListener(this);
		panel.add(registered);
		
		insert = new JButton("Insert");
		insert.setBounds(150, 260, 150, 30);
		insert.addActionListener(this);
		panel.add(insert);
		
		delete = new JButton("Delete");
		delete.setBounds(290, 160, 120, 30);
		delete.addActionListener(this);
		panel.add(delete);
		
		back = new JButton("back");
		back.setBounds(570, 300, 150, 30);
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
		
	}
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(hsc_reg))
					{hsc_reg.setText("");hire_check=true;}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(hsc_reg)&&hsc_reg.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter HSC Reg. no.");
					hsc_reg.setText("Hsc reg. no.");hire_check=false;
				}
				else{}
		}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			OfficerHome o = new OfficerHome(o_id,o_name,od_id,of_pass,a_id);
			o.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insert.getText()))
		{
			if(hire_check==true)
				{insertIntoDB();hire_check=false;}
			else
				{JOptionPane.showMessageDialog(this,"Please fill all information");}
		}
		else if(buttonClicked.equals(delete.getText()))
		{
			delete_from_db();
		}
		else if(buttonClicked.equals(registered.getText()))
		{
			JtableAdmissionExam r = new JtableAdmissionExam(o_id, o_name, od_id, of_pass, a_id);
			r.setVisible(true);
			this.setVisible(false);
		}
		
	}
	
	public void insertIntoDB()
	{
		String a=(String) combo1.getSelectedItem();
		String b=(String) combo2.getSelectedItem();
		String c=(String) combo3.getSelectedItem();
		String d=(String) combo4.getSelectedItem();
		
		
		String query="INSERT INTO addmission_exam VALUES ('"+a+"/"+b+"/"+c+"','"+d+"',"+0+",'"+hsc_reg.getText()+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void delete_from_db()
	{
		String query = "DELETE from addmission_exam where hsc_reg_no="+hsc_reg.getText()+";";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();
					
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}