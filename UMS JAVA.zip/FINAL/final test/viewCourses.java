import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;




public class viewCourses extends JFrame implements ActionListener
{
	private JLabel imgLabel;
	private JTextField search_field;
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back, search;
	private JPanel panel;
	//private String a_id, a_name, a_pass;
	private ImageIcon img;
	
	private String f_id, dept_id,f_name,f_pass,admin_id;
	
	public viewCourses(String f_id,String f_name,String f_Pass,String dept_id,String admin_id)
	{
		super("Courses");
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		this.f_id=f_id;
		this.dept_id=dept_id;
		this.admin_id=admin_id;
		this.f_pass=f_pass;
		this.f_name=f_name;
		
		panel = new JPanel();
		panel.setLayout(null);
		this.dept_id=dept_id;
		
		String columns[] =  {"Course ID","Course Name","Section","Faculty Name"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
		// specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,100,650,250);
		panel.add(tableScrollPane);
		
		
		search = new JButton("Search");
		search.setBounds(350, 370, 100, 30);
		search.addActionListener(this);
		search.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(search);
		
		search_field = new JTextField("Course Name");
		search_field.setBounds(200,370,100,30);
		search_field.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(search_field);
		
		back = new JButton("Back");
		back.setBounds(470, 370, 100, 30);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		back.addActionListener(this);
		panel.add(back);

	
		
		//String query = "SELECT `c_name`,`course`.`c_id`,`class_id` FROM `course`,`f_course` where `course`.`c_id`=`f_course`.`c_id`;"; 
       //String query = "SELECT `c_id`, `o_name`, `od_name`, `Admin_Id` FROM `oficers`, `odept` WHERE oficers.od_id=odept.od_id;";     
        
		

String q ="SELECT `faculties`.`f_name`,`c_name`,`course`.`c_id`,`class_id` FROM `course`,`f_course`,`faculties` where `course`.`c_id`=`f_course`.`c_id` and `faculties`.`f_id`=`f_course`.`f_id`;";
		Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(q);//getting result
			
			while(rs.next())
			{
                String course_id = rs.getString("c_id");
                String F_name = rs.getString("f_name");
				String Sec = rs.getString("class_id");
				String course_name = rs.getString("c_name");
				
				tableModel.addRow(new Object[]{course_id, course_name, Sec, F_name});
			}
		}
		catch(Exception e){}
		
		//img = new ImageIcon("u.jpg");
		//imgLabel = new JLabel(img);
		//imgLabel.setBounds(0,0,800,450);
		//panel.add(imgLabel);

		this.add(panel);
	}
	
	
	public void Search()
	{
		String CN=search_field.getText();
	
			String columns[] =  {"Course ID","Course Name","Section","Faculty Name"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,100,650,250);
		panel.add(tableScrollPane);

	String q ="SELECT `faculties`.`f_name`,`c_name`,`course`.`c_id`,`class_id` FROM `course`,`f_course`,`faculties` where `course`.`c_id`=`f_course`.`c_id` and `faculties`.`f_id`=`f_course`.`f_id`;";  
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(q);//getting result
		
			while(rs.next())
			{
                String course_id = rs.getString("c_id");
                String F_name = rs.getString("f_name");
				String Sec = rs.getString("class_id");
				String course_name = rs.getString("c_name");
				
				
				if(CN.equals(course_name))
					{
						tableModel.addRow(new Object[]{course_id, course_name, Sec, F_name});
									  
					}
					else{}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search.getText()))
		{
			Search();
		}
		else if(buttonClicked.equals(back.getText()))
		{
			TakeCourse tc = new TakeCourse(f_id,f_name,f_pass,dept_id,admin_id);
			tc.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
