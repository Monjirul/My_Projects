import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class FacultyProfile extends JFrame implements ActionListener
{
	private JLabel labelWelcome, labelName, labelNewPass, labelOldPass,labelId;
	private JButton buttonLogout, buttonChangePassword,Home,back;
	private JPanel panel;
	private JTextField oldPassword_field,newPassword_field;
	String f_id,f_pass,f_name,dept_id,admin_id;
	public FacultyProfile(String f_id,String f_name,String f_pass,String dept_id,String admin_id)
	{
		super("Faculty PROFILE");
		
		this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.f_id=f_id;
		this.f_pass=f_pass;
		this.dept_id=dept_id;
		this.admin_id=admin_id;
		this.f_name=f_name;
		panel = new JPanel();
		panel.setLayout(null);
		
		labelWelcome = new JLabel("FACULTY Account ");
		labelWelcome.setBounds(200, 20, 200, 30);
		panel.add(labelWelcome);
		
		labelName = new JLabel("Name	:	"+f_name);
		labelName.setBounds(200, 80, 200, 30);
		panel.add(labelName);
		
		
		labelId = new JLabel("ID	:"+f_id);
		labelId.setBounds(200, 120, 200, 30);
		panel.add(labelId);
		
		labelOldPass = new JLabel("OLD PASSWORD :");
		labelOldPass.setBounds(30, 220, 200, 30);
		panel.add(labelOldPass);
		
		labelNewPass = new JLabel("NEW PASSWORD :");
		labelNewPass.setBounds(30, 280, 200, 30);
		panel.add(labelNewPass);
		
		//labelNewPass = new JLabel("Salary	:	"+Emp_salary);
		//labelNewPass.setBounds(200, 150, 200, 30);
		//panel.add(labelNewPass);
		
		buttonChangePassword = new JButton("Change Password");
		buttonChangePassword.setBounds(150, 350, 150, 30);
		buttonChangePassword.addActionListener(this);
		panel.add(buttonChangePassword);
		
				back = new JButton("back");
		back.setBounds(0, 0, 150, 30);
		back.addActionListener(this);
		panel.add(back);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(320, 350, 150, 30);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
				oldPassword_field = new JTextField();              //password_field
		oldPassword_field.setBounds(220, 220, 150, 25);
		panel.add(oldPassword_field);
		
		
				newPassword_field = new JTextField();              //password_field
		newPassword_field.setBounds(220, 280, 150, 25);
		panel.add(newPassword_field);
		
		
		this.add(panel);
		
	}
	public void actionPerformed(ActionEvent ae){
		
			String buttonClicked = ae.getActionCommand();
		if(buttonClicked.equals(buttonLogout.getText()))
		{
		Login l = new Login();
		l.setVisible(true);
		this.setVisible(false);
		}
			else if(buttonClicked.equals(buttonChangePassword.getText()))
		{
			if(f_pass.equals(oldPassword_field.getText()))
			{
			Connection con=null;//for connection
			Statement st = null;//for query execution
			ResultSet rs = null;//to get row by row result from DB
			try{
				
				Class.forName("com.mysql.jdbc.Driver");//load driver
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
				st = con.createStatement();//create statement
			//	rs = st.executeQuery(query);//getting result

				String query = "update faculties set f_pass='"+newPassword_field.getText()+"' where f_id='"+f_id+"'";
				st.executeUpdate(query);
				st.close();
				con.close();
				rs.close();
			}
			catch(Exception e){}
		}
		else if(!f_pass.equals(oldPassword_field.getText())){
			JOptionPane.showMessageDialog(this,"Wrong Old Password");
			}
		}
		else if(buttonClicked.equals(back.getText()))
		{
			FacultyHome fh=new FacultyHome(f_id,f_name,f_pass,dept_id,admin_id);
			fh.setVisible(true);
			this.setVisible(false);
		}
		else{}
	}
}