-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2018 at 07:23 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ums`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmission`
--

CREATE TABLE `addmission` (
  `add_fee` double(8,2) NOT NULL,
  `s_id` varchar(10) NOT NULL,
  `hsc_reg_no` varchar(20) NOT NULL,
  `dept_id` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addmission`
--

INSERT INTO `addmission` (`add_fee`, `s_id`, `hsc_reg_no`, `dept_id`) VALUES
(20000.00, 'S-15451', '123456', '3567');

-- --------------------------------------------------------

--
-- Table structure for table `addmission_exam`
--

CREATE TABLE `addmission_exam` (
  `exam_date` varchar(10) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `marks_ob` double(8,2) DEFAULT NULL,
  `hsc_reg_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addmission_exam`
--

INSERT INTO `addmission_exam` (`exam_date`, `time`, `marks_ob`, `hsc_reg_no`) VALUES
('1/1/2017', '9:30 am', 80.00, '123456');

-- --------------------------------------------------------

--
-- Table structure for table `add_drop`
--

CREATE TABLE `add_drop` (
  `s_id` varchar(10) NOT NULL,
  `f_id` varchar(20) NOT NULL,
  `c_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `admin_name` varchar(25) NOT NULL,
  `admin_Id` varchar(20) NOT NULL,
  `ad_Pass` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_name`, `admin_Id`, `ad_Pass`) VALUES
('Admin', 'A-11', '1');

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_book`
--

CREATE TABLE `borrowed_book` (
  `return_date` varchar(10) NOT NULL,
  `brorrow_date` varchar(10) NOT NULL,
  `s_id` varchar(10) DEFAULT NULL,
  `b_id` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `c_id` varchar(20) NOT NULL,
  `c_name` varchar(25) NOT NULL,
  `credit_hour` int(11) NOT NULL,
  `dept_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`c_id`, `c_name`, `credit_hour`, `dept_id`) VALUES
('2657', 'English', 3, '3311'),
('2758', 'java', 3, '2654');

-- --------------------------------------------------------

--
-- Table structure for table `depertment`
--

CREATE TABLE `depertment` (
  `dept_id` varchar(4) NOT NULL,
  `d_name` varchar(20) NOT NULL,
  `add_fee` float(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `depertment`
--

INSERT INTO `depertment` (`dept_id`, `d_name`, `add_fee`) VALUES
('2654', 'CS', 20000.00),
('3311', 'ENGLISH', 20000.00),
('3567', 'EEE', 20000.00),
('5103', 'test', 20000.00),
('6584', 'hello', 20000.00);

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `f_id` varchar(20) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `f_pass` varchar(10) NOT NULL,
  `dept_id` varchar(4) DEFAULT NULL,
  `admin_Id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`f_id`, `f_name`, `f_pass`, `dept_id`, `admin_Id`) VALUES
('F-111', 'hello', '111', '6584', 'A-11'),
('F-6045', 'test', '1', '3311', 'A-11'),
('F-6122', 'test 2', '123', '6584', 'A-11');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_salary`
--

CREATE TABLE `faculty_salary` (
  `f_sal` double(8,2) DEFAULT NULL,
  `f_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_salary`
--

INSERT INTO `faculty_salary` (`f_sal`, `f_id`) VALUES
(25000.00, 'F-111'),
(123145.00, 'F-6045'),
(654621.00, 'F-6122');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `fees` double(8,2) NOT NULL,
  `c_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`fees`, `c_id`) VALUES
(15000.00, '2657'),
(17000.00, '2758');

-- --------------------------------------------------------

--
-- Table structure for table `f_course`
--

CREATE TABLE `f_course` (
  `f_id` varchar(10) NOT NULL,
  `c_id` varchar(10) NOT NULL,
  `class_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `f_course`
--

INSERT INTO `f_course` (`f_id`, `c_id`, `class_id`) VALUES
('F-6045', '2657', '2657-A'),
('F-111', '2758', '2758-A'),
('F-111', '2758', '2758-B'),
('F-111', '2758', '2758-C');

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE `library` (
  `b_id` varchar(5) NOT NULL,
  `b_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`b_id`, `b_name`) VALUES
('6785', 'MATH'),
('6875', 'JAVA');

-- --------------------------------------------------------

--
-- Table structure for table `lib_inv`
--

CREATE TABLE `lib_inv` (
  `b_id` varchar(25) NOT NULL,
  `copies` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lib_inv`
--

INSERT INTO `lib_inv` (`b_id`, `copies`) VALUES
('6785', 10),
('6875', 10);

-- --------------------------------------------------------

--
-- Table structure for table `odept`
--

CREATE TABLE `odept` (
  `od_id` varchar(4) NOT NULL,
  `od_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `odept`
--

INSERT INTO `odept` (`od_id`, `od_name`) VALUES
('481', 'hello'),
('7410', 'test 2'),
('7654', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `officers_sal`
--

CREATE TABLE `officers_sal` (
  `o_sal` double(8,2) NOT NULL,
  `o_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `officers_sal`
--

INSERT INTO `officers_sal` (`o_sal`, `o_id`) VALUES
(123451.00, 'O-6881'),
(464132.00, 'O-6742');

-- --------------------------------------------------------

--
-- Table structure for table `oficers`
--

CREATE TABLE `oficers` (
  `o_id` varchar(10) NOT NULL,
  `o_name` varchar(25) NOT NULL,
  `o_pass` varchar(10) NOT NULL,
  `od_id` varchar(3) NOT NULL,
  `Admin_Id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `oficers`
--

INSERT INTO `oficers` (`o_id`, `o_name`, `o_pass`, `od_id`, `Admin_Id`) VALUES
('O-6742', 'test 2', '123', '481', 'A-11'),
('O-6881', 'test', '1', '481', 'A-11');

-- --------------------------------------------------------

--
-- Table structure for table `regestration`
--

CREATE TABLE `regestration` (
  `year` varchar(4) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `hsc_reg_no` varchar(20) NOT NULL,
  `ssc_gpa` double(8,2) NOT NULL,
  `hsc_gpa` double(8,2) NOT NULL,
  `r_name` varchar(25) NOT NULL,
  `o_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regestration`
--

INSERT INTO `regestration` (`year`, `semester`, `hsc_reg_no`, `ssc_gpa`, `hsc_gpa`, `r_name`, `o_id`) VALUES
('2017', 'Summer', '123456', 2.00, 2.00, 'test', 'O-6881');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `cgpa` double(8,2) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `s_pass` varchar(10) NOT NULL,
  `s_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`cgpa`, `credits`, `s_pass`, `s_id`) VALUES
(0.00, 0, '123', 'S-15451');

-- --------------------------------------------------------

--
-- Table structure for table `s_course`
--

CREATE TABLE `s_course` (
  `s_id` varchar(10) NOT NULL,
  `class_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s_course`
--

INSERT INTO `s_course` (`s_id`, `class_id`) VALUES
('S-164573', '2758-A'),
('S-164533', '2758-A'),
('S-15451', '2758-D'),
('S-15451', '2657-A');

-- --------------------------------------------------------

--
-- Table structure for table `tpe`
--

CREATE TABLE `tpe` (
  `s_comment` varchar(50) DEFAULT NULL,
  `KNOWLEDGE` int(1) DEFAULT NULL,
  `MOTIVATION` int(1) NOT NULL,
  `PERSONALITY` int(1) NOT NULL,
  `STUDENT-FACULTY RELATION` int(1) NOT NULL,
  `ROUTINE` int(1) NOT NULL,
  `f_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tpe`
--

INSERT INTO `tpe` (`s_comment`, `KNOWLEDGE`, `MOTIVATION`, `PERSONALITY`, `STUDENT-FACULTY RELATION`, `ROUTINE`, `f_id`) VALUES
('BEST', 5, 0, 0, 0, 0, 'F-983456'),
('BEST', 5, 0, 0, 0, 0, 'F-986545'),
('good', 5, 5, 5, 5, 5, 'F-983456'),
('valo sir', 5, 5, 5, 5, 0, 'F-983456'),
('frqwwq', 2, 3, 4, 5, 0, 'hello'),
('super teacher', 5, 5, 5, 5, 0, 'test');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addmission`
--
ALTER TABLE `addmission`
  ADD PRIMARY KEY (`s_id`),
  ADD KEY `hsc_reg_no` (`hsc_reg_no`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `addmission_exam`
--
ALTER TABLE `addmission_exam`
  ADD PRIMARY KEY (`hsc_reg_no`);

--
-- Indexes for table `add_drop`
--
ALTER TABLE `add_drop`
  ADD KEY `s_id` (`s_id`),
  ADD KEY `f_id` (`f_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`admin_Id`);

--
-- Indexes for table `borrowed_book`
--
ALTER TABLE `borrowed_book`
  ADD KEY `s_id` (`s_id`),
  ADD KEY `b_id` (`b_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `course_ibfk_1` (`dept_id`);

--
-- Indexes for table `depertment`
--
ALTER TABLE `depertment`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `dept_id` (`dept_id`),
  ADD KEY `admin_Id` (`admin_Id`);

--
-- Indexes for table `faculty_salary`
--
ALTER TABLE `faculty_salary`
  ADD KEY `f_id` (`f_id`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `f_course`
--
ALTER TABLE `f_course`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `f_course_ibfk_1` (`c_id`);

--
-- Indexes for table `library`
--
ALTER TABLE `library`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `lib_inv`
--
ALTER TABLE `lib_inv`
  ADD KEY `lib_inv_ibfk_1` (`b_id`);

--
-- Indexes for table `odept`
--
ALTER TABLE `odept`
  ADD PRIMARY KEY (`od_id`);

--
-- Indexes for table `officers_sal`
--
ALTER TABLE `officers_sal`
  ADD KEY `o_id` (`o_id`);

--
-- Indexes for table `oficers`
--
ALTER TABLE `oficers`
  ADD PRIMARY KEY (`o_id`),
  ADD KEY `od_id` (`od_id`),
  ADD KEY `Admin_Id` (`Admin_Id`);

--
-- Indexes for table `regestration`
--
ALTER TABLE `regestration`
  ADD PRIMARY KEY (`hsc_reg_no`),
  ADD KEY `o_id` (`o_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `s_course`
--
ALTER TABLE `s_course`
  ADD KEY `s_course_ibfk_1` (`class_id`),
  ADD KEY `s_course_ibfk_2` (`s_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addmission`
--
ALTER TABLE `addmission`
  ADD CONSTRAINT `addmission_ibfk_1` FOREIGN KEY (`hsc_reg_no`) REFERENCES `addmission_exam` (`hsc_reg_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `addmission_ibfk_2` FOREIGN KEY (`dept_id`) REFERENCES `depertment` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `addmission_exam`
--
ALTER TABLE `addmission_exam`
  ADD CONSTRAINT `addmission_exam_ibfk_1` FOREIGN KEY (`hsc_reg_no`) REFERENCES `regestration` (`hsc_reg_no`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `add_drop`
--
ALTER TABLE `add_drop`
  ADD CONSTRAINT `add_drop_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `add_drop_ibfk_2` FOREIGN KEY (`f_id`) REFERENCES `faculties` (`f_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `add_drop_ibfk_3` FOREIGN KEY (`c_id`) REFERENCES `course` (`c_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `borrowed_book`
--
ALTER TABLE `borrowed_book`
  ADD CONSTRAINT `borrowed_book_ibfk_2` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `borrowed_book_ibfk_3` FOREIGN KEY (`b_id`) REFERENCES `library` (`b_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `depertment` (`dept_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `faculties`
--
ALTER TABLE `faculties`
  ADD CONSTRAINT `faculties_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `depertment` (`dept_id`),
  ADD CONSTRAINT `faculties_ibfk_2` FOREIGN KEY (`admin_Id`) REFERENCES `administrator` (`admin_Id`);

--
-- Constraints for table `faculty_salary`
--
ALTER TABLE `faculty_salary`
  ADD CONSTRAINT `faculty_salary_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `faculties` (`f_id`);

--
-- Constraints for table `fees`
--
ALTER TABLE `fees`
  ADD CONSTRAINT `fees_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `course` (`c_id`);

--
-- Constraints for table `f_course`
--
ALTER TABLE `f_course`
  ADD CONSTRAINT `f_course_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `course` (`c_id`);

--
-- Constraints for table `lib_inv`
--
ALTER TABLE `lib_inv`
  ADD CONSTRAINT `lib_inv_ibfk_1` FOREIGN KEY (`b_id`) REFERENCES `library` (`b_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `officers_sal`
--
ALTER TABLE `officers_sal`
  ADD CONSTRAINT `officers_sal_ibfk_1` FOREIGN KEY (`o_id`) REFERENCES `oficers` (`o_id`);

--
-- Constraints for table `oficers`
--
ALTER TABLE `oficers`
  ADD CONSTRAINT `oficers_ibfk_1` FOREIGN KEY (`od_id`) REFERENCES `odept` (`od_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `oficers_ibfk_2` FOREIGN KEY (`Admin_Id`) REFERENCES `administrator` (`admin_Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `regestration`
--
ALTER TABLE `regestration`
  ADD CONSTRAINT `regestration_ibfk_1` FOREIGN KEY (`o_id`) REFERENCES `oficers` (`o_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `addmission` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
