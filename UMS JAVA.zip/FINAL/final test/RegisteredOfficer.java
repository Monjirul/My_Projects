import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class RegisteredOfficer extends JFrame implements ActionListener, FocusListener
{
	private JLabel imgLabel;
	private JTextField search_field;
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back, search;
	private JPanel panel;
	private String a_id, a_name, a_pass;
	private ImageIcon img;
	
	
	public RegisteredOfficer(String a_name ,String a_id, String a_pass)
	{
		super("Registered Officer detail");
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.a_id=a_id;
		this.a_name=a_name;
		this.a_pass=a_pass;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		String columns[] =  {"Officer ID","Officer name","Depertment name","Admin Id"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
		// specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,100,650,250);
		panel.add(tableScrollPane);
		
		
		search = new JButton("Search");
		search.setBounds(350, 370, 100, 30);
		search.addActionListener(this);
		search.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(search);
		
		search_field = new JTextField("Officer name");
		search_field.setBounds(200,370,100,30);
		search_field.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		search_field.addFocusListener(this);
		panel.add(search_field);
		
		back = new JButton("Back");
		back.setBounds(470, 370, 100, 30);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		back.addActionListener(this);
		panel.add(back);

	
		
		
		String query = "SELECT `o_id`, `o_name`, `od_name`, `Admin_Id` FROM `oficers`, `odept` WHERE oficers.od_id=odept.od_id;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
                String F_id = rs.getString("o_id");
                String F_name = rs.getString("o_name");
				String Dept_id = rs.getString("od_name");
				String admin_Id = rs.getString("Admin_Id");
				
				tableModel.addRow(new Object[]{F_id, F_name, Dept_id, admin_Id});
			}
		}
		catch(Exception e){}
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);

		this.add(panel);
	}
	
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(search_field))
					{search_field.setText("");}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(search_field)&&search_field.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer name");
					search_field.setText("Officer name");
				}
				else{}
		}
	
	
	
	
	public void Search()
	{
		String Reg_noS=search_field.getText();
	
		String columns[] =  {"Officer ID","Officer name","Depertment name","Admin Id"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,100,650,250);
		panel.add(tableScrollPane);

		String query = "SELECT `o_id`, `o_name`, `od_name`, `Admin_Id` FROM `oficers`, `odept` WHERE oficers.od_id=odept.od_id;";   
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
				String F_id = rs.getString("o_id");
                String F_name = rs.getString("o_name");
				String Dept_id = rs.getString("od_name");
				String admin_Id = rs.getString("Admin_Id");
				
				
				if(Reg_noS.equals(F_name))
					{
						tableModel.addRow(new Object[]{F_id, F_name, Dept_id, admin_Id});
						break;			  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search.getText()))
		{
			Search();
		}
		else if(buttonClicked.equals(back.getText()))
		{
			AddOfficers ao = new AddOfficers(a_name,a_id,a_pass);
			ao.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
