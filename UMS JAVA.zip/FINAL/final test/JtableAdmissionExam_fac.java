import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class JtableAdmissionExam_fac extends JFrame implements ActionListener
{
	private JTextField search_field;
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back, search;
	private JPanel panel;
	//private String o_id, o_name, of_pass, a_id, od_id;
	Ad_marks am;
	
	public JtableAdmissionExam_fac(Ad_marks am)
	{
		super("Admission Exam detail");
		this.setSize(800,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		String columns[] =  {"Registration No","Name","SSC GPA","HSC GPA","Exam Marks"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
		// specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,50,650,250);
		panel.add(tableScrollPane);
		
		this.am=am;
		
		search = new JButton("SEARCH");
		search.setBounds(350, 320, 100, 30);
		search.addActionListener(this);
		panel.add(search);
		
		search_field = new JTextField("hsc_reg_no");
		search_field.setBounds(200,320,100,30);
		panel.add(search_field);
		
		back = new JButton("Back");
		back.setBounds(470, 320, 100, 30);
		back.addActionListener(this);
		panel.add(back);

	
		
		
		String query = "SELECT `regestration`.`r_name`,`regestration`.`hsc_reg_no`,`regestration`.`ssc_gpa`,`regestration`.`hsc_gpa`,`addmission_exam`.`marks_ob` FROM `regestration`,`addmission_exam` where `regestration`.`hsc_reg_no`=`addmission_exam`.`hsc_reg_no` ;";     
      

    	Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
                String name = rs.getString("r_name");
                String reg_no = rs.getString("hsc_reg_no");
				double ssc_g = rs.getInt("ssc_gpa");
				double hsc_g = rs.getInt("hsc_gpa");
				double Marks_ob = rs.getDouble("marks_ob");
				
				
				tableModel.addRow(new Object[]{reg_no, name, ssc_g, hsc_g, Marks_ob});
			}
		}
		catch(Exception e){}

		this.add(panel);
	}
	
	
	public void Search()
	{
		String Reg_noS=search_field.getText();
	
		String columns[] =  {"Registration No","Name","SSC GPA","HSC GPA","Exam Marks"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,50,650,250);
		panel.add(tableScrollPane);

		String query = "SELECT `regestration`.`r_name`,`regestration`.`hsc_reg_no`,`regestration`.`ssc_gpa`,`regestration`.`hsc_gpa`,`addmission_exam`.`marks_ob` FROM `regestration`,`addmission_exam` where `regestration`.`hsc_reg_no`=`addmission_exam`.`hsc_reg_no` ;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
                      String name = rs.getString("r_name");
                String reg_no = rs.getString("hsc_reg_no");
				double ssc_g = rs.getInt("ssc_gpa");
				double hsc_g = rs.getInt("hsc_gpa");
				double Marks_ob = rs.getDouble("marks_ob");
				
				
				if(Reg_noS.equals(reg_no))
					{
							tableModel.addRow(new Object[]{reg_no, name, ssc_g, hsc_g, Marks_ob});
						break;			  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search.getText()))
		{
			Search();
		}
		else if(buttonClicked.equals(back.getText()))
		{
	
			am.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
