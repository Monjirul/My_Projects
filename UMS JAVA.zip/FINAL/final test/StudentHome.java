import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

public class StudentHome extends JFrame implements ActionListener
{
	private JLabel labelWelcome, labelName, labelNumber, labelBalance,labelCredit,imgLabel;
	private JButton buttonLogout, buttonProfile,buttonLibrary,buttonTPE;
	private JPanel panel;
	 String name;
	 double cgpa;
	 int credits;
	 String s_Pass,s_id;
	 String dname;
	 private ImageIcon img;	
	public StudentHome(double cgpa,int credits,String s_Pass,String s_id)
	{
		super("Student Home Window");
		
		this.setSize(818, 493);
		//this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getSname(s_id);///getting students name
		
		panel = new JPanel();
		panel.setLayout(null);
		
		this.s_Pass=s_Pass;
		this.cgpa=cgpa;
		this.credits=credits;
		this.s_id=s_id;
				
		buttonLibrary = new JButton("Library");
		buttonLibrary.setBounds(500, 150, 150, 30);
		buttonLibrary.addActionListener(this);
		panel.add(buttonLibrary);
		
		
		
	    labelWelcome = new JLabel("Student Account");
		labelWelcome.setBounds(200, 100, 200, 30);
		labelWelcome.setForeground(Color.white);
		labelWelcome.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(labelWelcome);
		
		labelName = new JLabel("Student Name	:	"+name);
		labelName.setBounds(200, 150, 200, 30);
		labelName.setForeground(Color.white);
		labelName.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(labelName);
		
		labelNumber = new JLabel("Student ID	:	"+s_id);
		labelNumber.setBounds(200, 200, 200, 30);
		labelNumber.setForeground(Color.white);
		labelNumber.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(labelNumber);
		
		
		buttonProfile = new JButton("Profile");
		buttonProfile.setBounds(150, 300, 150, 30);
		buttonProfile.addActionListener(this);
		panel.add(buttonProfile);
		
		buttonLogout = new JButton("Logout");
		buttonLogout.setBounds(320, 300, 150, 30);
		buttonLogout.addActionListener(this);
		panel.add(buttonLogout);
		
		
		buttonTPE = new JButton("TPE");
		buttonTPE.setBounds(500, 200, 150, 30);
		buttonTPE.addActionListener(this);
		panel.add(buttonTPE);
		
				
			img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		this.add(panel);
		
	}
	
	public void getSname(String ss_id)
	{
		

	  
	  	String Reg_no="";			
		String d_id="";	
		
	     String chk_id=ss_id;
	  	System.out.println(chk_id);
	
	
	String query1="SELECT  `s_id`, `hsc_reg_no`,`dept_id` FROM `addmission`;";
	  String query2 = "SELECT `hsc_reg_no`, `r_name` FROM `regestration`;" ;
	
	    Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query1);
		
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query1);//getting result
			System.out.println("results received");
		
	
			
		   while(rs.next())
			{
			
         		String hsc_reg_no = rs.getString("hsc_reg_no");
			    String s_id = rs.getString("s_id");
                String dept_id = rs.getString("dept_id");
			
				
				if(s_id.equals(chk_id))
				{
						
		       Reg_no=hsc_reg_no;
			   d_id=dept_id;
	
			rs = st.executeQuery(query2);
			System.out.println("results received");

     		   while(rs.next())
			{
				 hsc_reg_no = rs.getString("hsc_reg_no");
				String r_name = rs.getString("r_name");
			if(hsc_reg_no.equals(Reg_no))
			{
				 name=r_name;
				String query3="SELECT `d_name`, `dept_id` FROM `depertment`;" ;
	          	rs = st.executeQuery(query3);
		   while(rs.next())
			{
				 dept_id = rs.getString("dept_id");
				String d_name=rs.getString("d_name");
				if(dept_id.equals(d_id))
				{
					dname=d_name;
				}
			}

		}
			else{}
			}
				}
				
					else
					{
						//JOptionPane.showMessageDialog(this,"Invalid pass"); 
					}
				}
	}
	    catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
	}
	public void actionPerformed(ActionEvent ae){
		
			String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(buttonProfile.getText()))
		{
			StudentProfile sp = new StudentProfile(cgpa,credits,s_Pass,s_id,name,dname,this);
			sp.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(buttonLogout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(buttonLibrary.getText()))
		{
			
			JtableLibrary l=new JtableLibrary(this);
			l.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(buttonTPE.getText()))
		{
			Tpe t= new Tpe(s_id,this);
			t.setVisible(true);
			this.setVisible(false);
			
		}
	
		else{}
		
	}
}