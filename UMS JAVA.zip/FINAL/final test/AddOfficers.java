import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

class AddOfficers extends JFrame implements ActionListener, FocusListener
{
	private JLabel o_name, o_id, o_pass, dept_id, d_label, o_sal, imgLabel;
	private JButton back, insert, delete, registered;
	private JPanel panel;
	private JTextField officer_id, officer_name, officer_pass, department_id, officer_salary;
	private String a_id, a_name, a_pass;
	private JComboBox combo;
	private Random rand=new Random();
	private int r;
	private String F_name[]=new String[10];
	private String F_id[]=new String[10];
	private ImageIcon img;
	private boolean hire_check=false;

	
	
	
	public AddOfficers( String a_name ,String a_id, String a_pass)
	{
		super("Officers Registration");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.a_id=a_id;
		this.a_name=a_name;
		this.a_pass=a_pass;
		

		panel = new JPanel();
		panel.setLayout(null);
		
		o_name = new JLabel("Officer Name : ");  //registration welcome
		o_name.setBounds(20, 110, 200, 30);
		o_name.setForeground(Color.white);
		o_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(o_name);
		
		o_id = new JLabel("Officer ID : ");  //registration welcome
		o_id.setBounds(20, 150, 200, 30);
		o_id.setForeground(Color.white);
		o_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(o_id);
		
		o_pass = new JLabel("Officer Password : ");  //registration welcome
		o_pass.setBounds(20, 190, 200, 30);
		o_pass.setForeground(Color.white);
		o_pass.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(o_pass);
		
		dept_id = new JLabel("Department Name : ");  //registration welcome
		dept_id.setBounds(20, 230, 200, 30);
		dept_id.setForeground(Color.white);
		dept_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(dept_id);
		
		o_sal = new JLabel("Officer Salary : ");  //registration welcome
		o_sal.setBounds(20, 270, 200, 30);
		o_sal.setForeground(Color.white);
		o_sal.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(o_sal);
		
		d_label = new JLabel("Delete with Officers ID");  //registration welcome
		d_label.setBounds(440, 150, 350, 30);
		d_label.setForeground(Color.white);
		d_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(d_label);
			
		
	////////////////////////////////////////////////////////////////////////
	r=rand.nextInt(999)+6000;

		officer_name = new JTextField("Officer name");  
		officer_name.setBounds(220, 110, 150, 25);
		officer_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		officer_name.addFocusListener(this);
		panel.add(officer_name);

		
		officer_id = new JTextField("O-"+r); 
		officer_id.setBounds(220, 150, 100, 25);
		officer_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		officer_id.addFocusListener(this);
		panel.add(officer_id);
		
		officer_pass = new JTextField("Officer Pass");   
		officer_pass.setBounds(220, 190, 100, 25);
		officer_pass.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		officer_pass.addFocusListener(this);
		panel.add(officer_pass);
		
		//-------------------------------------------------------------------------------------
		

		String q = "SELECT `od_id`, `od_name` FROM `odept`;";
		String query2 = "SELECT `o_id` FROM `oficers`;";
        try
		{
			int i=0;
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement st2 = con.createStatement();
			ResultSet rs1 = stm.executeQuery(q);
			ResultSet rs2 = st2.executeQuery(query2);
			
			while(rs1.next())
			{
				F_id [i]= rs1.getString("od_id");
				F_name [i] = rs1.getString("od_name");
				i++;
			}
			while(rs2.next())
			{
				String O_id = rs2.getString("o_id");
				String temp="O-"+r;
				if(O_id==temp)
				{r=rand.nextInt(999)+6000;officer_id.setText("O-"+r);}
				else{officer_id.setText("O-"+r);}
			}
			st2.close();
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		
		
		//-------------------------------------------------------------------------------------------
		
		
		
		//String s[] = {"CSE", "CS", "CSSE", "SE", "CIS"};
		combo = new JComboBox(F_name);
		combo.setBounds(220, 230, 120, 25);
		combo.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo);	
		
		officer_salary = new JTextField("Officer salary");
		officer_salary.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));		
		officer_salary.setBounds(220, 270, 120, 25);
		officer_salary.addFocusListener(this);
		panel.add(officer_salary);

		
		registered = new JButton("Showtable");
		registered.setBounds(500, 270, 200, 50);
		registered.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		registered.addActionListener(this);
		panel.add(registered);
		
		insert = new JButton("Hire");
		insert.setBounds(220, 340, 150, 40);
		insert.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		insert.addActionListener(this);
		panel.add(insert);
		
		delete = new JButton("Delete");
		delete.setBounds(330, 150, 100, 30);
		delete.addActionListener(this);
		panel.add(delete);
		
		back = new JButton("Back");
		back.setBounds(500, 340, 200, 50);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
		
	}
	
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(officer_name))
					{officer_name.setText(""); hire_check=true; }
				else if(e.getSource().equals(officer_id))
					{officer_id.setText(""); hire_check=true; }
				else if(e.getSource().equals(officer_pass))
					{officer_pass.setText(""); hire_check=true;}
				else if(e.getSource().equals(officer_salary))
					{officer_salary.setText("");hire_check=true;}
				else{}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(officer_name)&&officer_name.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer name");
					officer_name.setText("Officer name");hire_check=false;
				}
				else if(e.getSource().equals(officer_id)&&officer_id.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer Id");
					officer_id.setText("O-"+r);hire_check=false;
				}
				else if(e.getSource().equals(officer_pass)&&officer_pass.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer password");
					officer_pass.setText("Officer Pass");hire_check=false;
				}
				else if(e.getSource().equals(officer_salary)&&officer_salary.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer salary");
					officer_salary.setText("Officer Salary");hire_check=false;
				}
				else{}
		}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			AdminHome a= new AdminHome(a_name,a_id,a_pass);
			a.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insert.getText()))
		{
			if(hire_check==true)
				{insertIntoDB();hire_check=false;}
			else
				{JOptionPane.showMessageDialog(this,"Please fill all information");}
		}
		else if(buttonClicked.equals(delete.getText()))
		{
			delete_from_db();
		}
		else if(buttonClicked.equals(registered.getText()))
		{
			RegisteredOfficer rf = new RegisteredOfficer(a_name,a_id,a_pass);
			rf.setVisible(true);
			this.setVisible(false);
		}
		
	}
	
	public void insertIntoDB()
	{
		String temp=(String) combo.getSelectedItem();
		int i=0;
		
		for(i=0;i<10;i++)
		{
			if(F_name[i]==temp)
			{temp=F_id[i];System.out.println(temp);System.out.println(officer_id.getText());}
		}
		
		String query="INSERT INTO oficers VALUES ('"+officer_id.getText()+"','"+officer_name.getText()+"','"+officer_pass.getText()+"','"+temp+"','"+a_id+"');";
		String q="INSERT INTO officers_sal VALUES ("+officer_salary.getText()+",'"+"O-"+r+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement s= con.createStatement();
			stm.execute(query);
			s.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void delete_from_db()
	{
		String query = "DELETE from oficers where o_id='"+officer_id.getText()+"';";
		String q="DELETE from officers_sal where o_id='"+officer_id.getText()+"';";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement s= con.createStatement();
			s.execute(q);
			stm.execute(query);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}