import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class JtableAdmission extends JFrame implements ActionListener, FocusListener
{
	private JLabel imgLabel;
	private JTextField search_field;
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back, search;
	private JPanel panel;
	private String o_id, o_name, of_pass, a_id, od_id;
	private ImageIcon img;	
	
	public JtableAdmission(String o_id, String o_name, String od_id, String of_pass, String a_id)
	{
		super("Admission detail");
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.a_id=a_id;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		String columns[] =  {"Student name","Student ID","HSC Reg.","Department name","Add. fee"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
		// specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,80,650,250);
		panel.add(tableScrollPane);
		
		
		search = new JButton("Search");
		search.setBounds(350, 350, 100, 30);
		search.addActionListener(this);
		panel.add(search);
		
		search_field = new JTextField("Student name");
		search_field.setBounds(200,350,100,30);
		search_field.addFocusListener(this);
		panel.add(search_field);
		
		back = new JButton("Back");
		back.setBounds(470, 350, 100, 30);
		back.addActionListener(this);
		panel.add(back);

	
		
		
		String query = "SELECT addmission.add_fee,`s_id`, addmission.hsc_reg_no, `d_name`, `r_name` FROM `addmission`, `depertment`,`regestration` WHERE addmission.dept_id=depertment.dept_id and addmission.hsc_reg_no=regestration.hsc_reg_no;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
                double Add_fee = rs.getDouble("add_fee");
                String S_id = rs.getString("s_id");
				String Hsc_reg_no = rs.getString("hsc_reg_no");
				String Dept_id = rs.getString("d_name");
				String S_name = rs.getString("r_name");
				
				
				tableModel.addRow(new Object[]{S_name, S_id, Hsc_reg_no, Dept_id, Add_fee});
			}
		}
		catch(Exception e){}
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);

		this.add(panel);
	}
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(search_field))
					{search_field.setText("");}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(search_field)&&search_field.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter student name");
					search_field.setText("Student name");
				}
				else{}
		}
	
	
	public void Search()
	{
		String Reg_noS=search_field.getText();
	
		String columns[] =  {"Student name","Student ID","HSC Reg.","Department name","Add. fee"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,80,650,250);
		panel.add(tableScrollPane);

		String query = "SELECT addmission.add_fee,`s_id`, addmission.hsc_reg_no, `d_name`, `r_name` FROM `addmission`, `depertment`,`regestration` WHERE addmission.dept_id=depertment.dept_id and addmission.hsc_reg_no=regestration.hsc_reg_no;";   
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
                double Add_fee = rs.getDouble("add_fee");
                String S_id = rs.getString("s_id");
				String Hsc_reg_no = rs.getString("hsc_reg_no");
				String Dept_id = rs.getString("d_name");
				String S_name = rs.getString("r_name");
				
				if(Reg_noS.equals(S_name))
					{
						tableModel.addRow(new Object[]{S_name, S_id, Hsc_reg_no, Dept_id, Add_fee});		  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search.getText()))
		{
			Search();
		}
		else if(buttonClicked.equals(back.getText()))
		{
			Admission a = new Admission(o_id, o_name, od_id, of_pass, a_id);
			a.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
