import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

class AddDepartment extends JFrame implements ActionListener, FocusListener
{
	private JLabel df_name, df_id, do_name, do_id, df_label, do_label, hf, ho, imgLabel, add_fee;
	private JButton back, insertf, inserto, deletef, deleteo, registered;
	private JPanel panel;
	private JTextField faculty_id, faculty_name, officers_name, officers_id, addmission_fee;
	private String a_id, a_name, a_pass;
	private ImageIcon img;
	private Random rand=new Random();
	private int r1, r2;
	
	
	
	public AddDepartment( String a_name ,String a_id, String a_pass)
	{
		super("Department Setup");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.a_id=a_id;
		this.a_name=a_name;
		this.a_pass=a_pass;
		

		panel = new JPanel();
		panel.setLayout(null);
		
		hf = new JLabel("Faculties and Students department ");  //registration welcome
		hf.setBounds(20, 60, 350, 30);
		hf.setForeground(Color.white);
		hf.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(hf);
		
		df_name = new JLabel("Department Name : ");  //registration welcome
		df_name.setBounds(20, 100, 200, 30);
		df_name.setForeground(Color.white);
		df_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(df_name);
		
		
		df_id = new JLabel("Department Id : ");  //registration welcome
		df_id.setBounds(20, 140, 200, 30);
		df_id.setForeground(Color.white);
		df_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(df_id);
		
		add_fee = new JLabel("Department add. fee :");  //registration welcome
		add_fee.setBounds(20, 190, 220, 30);
		add_fee.setForeground(Color.white);
		add_fee.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(add_fee);
		
		df_label = new JLabel("Delete with department ID");  //registration welcome
		df_label.setBounds(460, 140, 350, 30);
		df_label.setForeground(Color.white);
		df_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(df_label);
		
		ho = new JLabel("Officers department");  //registration welcome
		ho.setBounds(20, 270, 200, 30);
		ho.setForeground(Color.white);
		ho.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(ho);
		
		do_name = new JLabel("Department Name : ");  //registration welcome
		do_name.setBounds(20, 310, 200, 30);
		do_name.setForeground(Color.white);
		do_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(do_name);
		
		do_id = new JLabel("Department Id : ");  //registration welcome
		do_id.setBounds(20, 350, 200, 30);
		do_id.setForeground(Color.white);
		do_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(do_id);
		
		do_label = new JLabel("Delete with department ID");  //registration welcome
		do_label.setBounds(440, 350, 350, 30);
		do_label.setForeground(Color.white);
		do_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(do_label);
			
		
	////////////////////////////////////////////////////////////////////////

		faculty_name = new JTextField("Faculty dep. name");  
		faculty_name.setBounds(240, 100, 150, 25);
		faculty_name.addFocusListener(this);
		panel.add(faculty_name);
		
		r1=rand.nextInt(999)+5000;
		
		faculty_id = new JTextField(""+r1); 
		faculty_id.setBounds(240, 140, 100, 25);
		faculty_id.addFocusListener(this);
		panel.add(faculty_id);
		
		addmission_fee = new JTextField("Dept add. fee");  
		addmission_fee.setBounds(240, 190, 100, 25);
		addmission_fee.addFocusListener(this);
		panel.add(addmission_fee);
		
		String query2 = "SELECT `dept_id`, `d_name` FROM `depertment`;";
        try
		{

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement st2 = con.createStatement();
			ResultSet rs2 = st2.executeQuery(query2);
			
			while(rs2.next())
			{
				String O_id = rs2.getString("dept_id");
				String temp=""+r1;
				if(O_id==temp)
				{r1=rand.nextInt(999)+5000;faculty_id.setText(""+r1);}
				else{faculty_id.setText(""+r1);}
			}
			st2.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		
		officers_name = new JTextField("Officers dept. name");   
		officers_name.setBounds(220, 310, 150, 25);
		officers_name.addFocusListener(this);
		panel.add(officers_name);
		
		r2=rand.nextInt(999)+7000;
		
		
		officers_id = new JTextField(""+r2);  
		officers_id.setBounds(220, 350, 100, 25);
		officers_id.addFocusListener(this);
		panel.add(officers_id);
		
		
		
		String q = "SELECT `od_id`, `od_name` FROM `odept`;";
        try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			ResultSet rs1 = stm.executeQuery(q);
			
			while(rs1.next())
			{
				String O_id = rs1.getString("od_id");
				String temp=""+r2;
				if(O_id==temp)
				{r2=rand.nextInt(999)+7000;officers_id.setText(""+r2);}
				else{officers_id.setText(""+r2);}
			}
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		insertf = new JButton("FD.insert");
		insertf.setBounds(150, 225, 100, 30);
		insertf.addActionListener(this);
		panel.add(insertf);
		
		inserto = new JButton("OD.insert");
		inserto.setBounds(150, 385, 100, 30);
		inserto.addActionListener(this);
		panel.add(inserto);
		
		deletef = new JButton("FD.delete");
		deletef.setBounds(350, 140, 100, 30);
		deletef.addActionListener(this);
		panel.add(deletef);
		
		deleteo = new JButton("OD.delete");
		deleteo.setBounds(330, 350, 100, 30);
		deleteo.addActionListener(this);
		panel.add(deleteo);
		
		registered = new JButton("Showtable");
		registered.setBounds(470, 405, 100, 30);
		registered.addActionListener(this);
		panel.add(registered);
		
		back = new JButton("Back");
		back.setBounds(350, 405, 100, 30);
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
		
	}
	
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(faculty_name))
					{faculty_name.setText(""); }
				else if(e.getSource().equals(faculty_id))
					{faculty_id.setText(""); }
				else if(e.getSource().equals(addmission_fee))
					{addmission_fee.setText(""); }
				else if(e.getSource().equals(officers_name))
					{officers_name.setText("");}
				else if(e.getSource().equals(officers_id))
					{officers_id.setText("");}
				else{}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(faculty_name)&&faculty_name.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter faculty dept. name");
					faculty_name.setText("faculty dept. name");
				}
				else if(e.getSource().equals(faculty_id)&&faculty_id.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter faculty dept. id");
					faculty_id.setText(""+r1);
				}
				else if(e.getSource().equals(addmission_fee)&&addmission_fee.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter addmission fee");
					addmission_fee.setText("Dept add. fee ");
				}
				else if(e.getSource().equals(officers_name)&&officers_name.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer dept. name");
					officers_name.setText("Officer dept. name");
				}
				else if(e.getSource().equals(officers_id)&&officers_id.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter officer dept. id");
					officers_id.setText(""+r2);
				}
				else{}
		}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(back.getText()))
		{
			AdminHome a= new AdminHome(a_name,a_id,a_pass);
			a.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(insertf.getText()))
		{
			String q="INSERT INTO depertment VALUES ('"+faculty_id.getText()+"','"+faculty_name.getText()+"','"+addmission_fee.getText()+"');";
			insertIntoDB(q);
		}
		else if(buttonClicked.equals(deletef.getText()))
		{
			String q = "DELETE from depertment where dept_id='"+faculty_id.getText()+"';";
			delete_from_db(q);
		}
		else if(buttonClicked.equals(inserto.getText()))
		{
			String q="INSERT INTO odept VALUES ('"+officers_id.getText()+"','"+officers_name.getText()+"');";
			insertIntoDB(q);
		}
		else if(buttonClicked.equals(deleteo.getText()))
		{
			String q="DELETE from odept where od_id='"+officers_id.getText()+"';";
			delete_from_db(q);
		}
		else if(buttonClicked.equals(registered.getText()))
		{
			JtableAddDepartment rf = new JtableAddDepartment(a_name,a_id,a_pass);
			rf.setVisible(true);
			this.setVisible(false);
		}
		
	}
	
	public void insertIntoDB(String q)
	{
		
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	public void delete_from_db(String q)
	{
		
		
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			stm.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		System.out.println("---Row deleted---");
    }
	
}