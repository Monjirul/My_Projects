import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class OficcerProfile extends JFrame implements ActionListener, FocusListener
{
	private JLabel profile_name, profile_id, admin_name, admin_id, profile_password, department_name, pass_label, imgLabel;
	private JButton logout, change_password, back;
	private JPanel panel;
	private JTextField password_field, old_pass_field;
	private String o_id, o_name, of_pass, a_id, new_password, d_name, a_name, od_id;
	private ImageIcon img;
	
	
	public OficcerProfile(String o_id, String o_name, String od_id, String of_pass, String a_id)
	{
		super("Officer Profile");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.a_id=a_id;
		
		
		profile_name = new JLabel("Name : "+o_name);  //profile_name
		profile_name.setBounds(20, 110, 300, 30);
		profile_name.setForeground(Color.white);
		profile_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(profile_name);
		
		profile_id = new JLabel("ID : "+o_id);     //profile_id
		profile_id.setBounds(20, 150, 150, 30);
		profile_id.setForeground(Color.white);
		profile_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(profile_id);
		
		
		names();
		
		admin_name = new JLabel("Admin name : "+a_name);  //Admin_name
		admin_name.setBounds(340, 110, 300, 30);
		admin_name.setForeground(Color.white);
		admin_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(admin_name);
		
		admin_id = new JLabel("Admin Id : "+a_id);  //Admin_Id`
		admin_id.setBounds(340, 150, 250, 30);
		admin_id.setForeground(Color.white);
		admin_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(admin_id);
		
		department_name = new JLabel("Department name : "+d_name);  //department name
		department_name.setBounds(20, 190, 350, 30);
		department_name.setForeground(Color.white);
		department_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(department_name);
	
		pass_label = new JLabel("New password :");  //department name
		pass_label.setBounds(20, 250, 180, 30);
		pass_label.setForeground(Color.white);
		pass_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(pass_label);
		
		old_pass_field = new JTextField("Old password check");         //password_field
		old_pass_field.setBounds(200, 250, 200, 30);
		old_pass_field.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		old_pass_field.addFocusListener(this);
		panel.add(old_pass_field);
		
		password_field = new JTextField("New password");         //password_field
		password_field.setBounds(200, 290, 200, 30);
		password_field.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		password_field.addFocusListener(this);
		panel.add(password_field);
		
		change_password = new JButton("Change Password");   //button change password
		change_password.setBounds(200, 330, 200, 40);
		change_password.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,16));
		change_password.addActionListener(this);
		panel.add(change_password);
		
		logout = new JButton("Logout");    //button logout
		logout.setBounds(450, 340, 100, 40);
		logout.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		logout.addActionListener(this);
		panel.add(logout);
		
		back = new JButton("Back");     //button back
		back.setBounds(570, 340, 100, 40);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
		
	}
	
	
	
	public void focusGained(FocusEvent e) 
		{
			if(e.getSource().equals(old_pass_field))
				old_pass_field.setText(""); 
			else if(e.getSource().equals(password_field))
				password_field.setText(""); 
			else{}
		}

	public void focusLost(FocusEvent e)
		{
			if(e.getSource().equals(old_pass_field)&&old_pass_field.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter old password");
					old_pass_field.setText("Old password");
				}
			else if(e.getSource().equals(password_field)&&password_field.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter new password");
					password_field.setText("New password");
				}
			else{}
		}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(logout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(change_password.getText()))
		{
			System.out.println(of_pass);
			if(old_pass_field.getText().equals(of_pass))
				{
					String query = "SELECT `o_id`, `o_name`, `o_pass`, `od_id`, `Admin_Id` FROM `oficers`;";     
					Connection con=null;//for connection
					Statement st = null;//for query execution
					ResultSet rs = null;//to get row by row result from DB
					try
						{
							Class.forName("com.mysql.jdbc.Driver");//load driver
							con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
							st = con.createStatement();//create statement
							rs = st.executeQuery(query);//getting result
							System.out.println(o_id);
							query = "update oficers set o_pass='"+password_field.getText()+"' where o_id='"+o_id+"'";
							st.executeUpdate(query);
							st.close();
							con.close();
							rs.close();
						}
					catch(Exception e){}
				}
			else{JOptionPane.showMessageDialog(this,"Password Mismatch");}
		}
		else if(buttonClicked.equals(back.getText()))
		{
			OfficerHome o = new OfficerHome(o_id,o_name,od_id,of_pass,a_id);
			o.setVisible(true);
			this.setVisible(false);
		}
		else{}
	}
	
	public void names()
	{
		String query1 = "SELECT `admin_name`, `admin_Id`, `ad_Pass` FROM `administrator`;";  
		String query2 = "SELECT `od_id`, `od_name` FROM `odept`;";   
        Connection con=null;//for connection
        Statement st1 = null, st2 = null;//for query execution
		ResultSet rs1 = null, rs2 = null;//to get row by row result from DB
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st1 = con.createStatement();//create statement
			rs1 = st1.executeQuery(query1);//getting result
			st2 = con.createStatement();//create statement
			rs2 = st2.executeQuery(query2);//getting result
					
			while(rs2.next())
			{
				String Odcheck = rs2.getString("od_id");	
				
				if(od_id.equals(Odcheck))
				{
					d_name = rs2.getString("od_name");
				}	
			}
			while(rs1.next())
			{
				String adcheck=rs1.getString("admin_Id");

				if(a_id.equals(adcheck))
				{
					a_name = rs1.getString("admin_name");
				}
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs1!=null)
					rs1.close();rs2.close();

                if(st1!=null)
					st1.close();st2.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
	}
	
	
}