import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;




public class Ad_marks extends JFrame implements ActionListener
{               

                 
	private JLabel Hsc_reg,Marks_Obt;
	
	private JButton Confirm, viewStudents,back;
	private JPanel panel;
	private JTextField mark_txt,reg_txt;
	int flag=0;
	FacultyHome fh;
	public Ad_marks(FacultyHome fh)
	{
		super("Admission Marks");
		this.setSize(800,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	   panel = new JPanel();
		panel.setLayout(null);
		
		this.fh=fh;
		
		Hsc_reg=new JLabel("Registration No :");
		Hsc_reg.setBounds(10, 100, 150, 30);
		panel.add(Hsc_reg);
		
		reg_txt=new JTextField();
		reg_txt.setBounds(180, 100, 150, 30);
		reg_txt.addActionListener(this);
		panel.add(reg_txt);
		
		
		Marks_Obt=new JLabel("Marks Obtained :");
		Marks_Obt.setBounds(10, 150, 150, 30);
		panel.add(Marks_Obt);
		
		mark_txt=new JTextField();
		mark_txt.setBounds(180, 150, 150, 30);
		mark_txt.addActionListener(this);
		panel.add(mark_txt);
		
		
		back = new JButton("BACK");
		back.setBounds(450, 0, 100, 60);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,12));
		back.addActionListener(this);
		panel.add(back);
		
					Confirm = new JButton("Confirm");
		Confirm.setBounds(200,200, 150, 60);
		Confirm.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,12));
		Confirm.addActionListener(this);
		panel.add(Confirm);
		
		viewStudents = new JButton("View Students");
		viewStudents.setBounds(400, 200, 150, 60);
		viewStudents.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,12));
		viewStudents.addActionListener(this);
		panel.add(viewStudents);
		
			this.add(panel);
	}
	
		public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(Confirm.getText()))
		{
		updateDB();
		
		}
		else if(buttonClicked.equals(back.getText()))
		{
			//TakeCourse tc = new TakeCourse(f_id,f_name,f_pass,dept_id,admin_id);
			fh.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(viewStudents.getText()))
		{
		JtableAdmissionExam_fac jaf=new JtableAdmissionExam_fac(this);
		jaf.setVisible(true);
		this.setVisible(false);
		}
        else{}
	}
	
	public void updateDB()
	{
	
	System.out.println("DHUKSE");
	String query = "update addmission_exam set marks_ob='"+mark_txt.getText()+"' where hsc_reg_no='"+reg_txt.getText()+"'";
	       
	System.out.println(query);
		   Connection con=null;//for connection
			Statement st = null;//for query execution
			ResultSet rs = null;//to get row by row result from DB
			try
			{
				Class.forName("com.mysql.jdbc.Driver");//load driver
				System.out.println("Drver load");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			
				st = con.createStatement();//create statement
				System.out.println("connection ST");
				//rs = st.executeQuery(query);//getting result
				System.out.println("result set");
				System.out.println(query);
				
				st.executeUpdate(query);
				//a_pass=password_field.getText();
				st.close();
				con.close();
				rs.close();
			}
			catch(Exception e){}
	}

}