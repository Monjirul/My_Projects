import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class JtableAddDepartment extends JFrame implements ActionListener, FocusListener
{
	private JLabel t1, t2, imgLabel;
	private JTextField search_field1, search_field2;
	private JTable contactTable1, contactTable2;
	private JScrollPane tableScrollPane1, tableScrollPane2, tableScrollPane;
	private JButton back, search1, search2;
	private JPanel panel;
	private String a_id, a_name, a_pass;
	private ImageIcon img;
	
	
	public JtableAddDepartment(String a_name ,String a_id, String a_pass)
	{
		super("Registered Officer detail");
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.a_id=a_id;
		this.a_name=a_name;
		this.a_pass=a_pass;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		t1 = new JLabel("Faculties and Students department");  //profile_name
		t1.setBounds(50, 60, 350, 30);
		t1.setForeground(Color.white);
		t1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(t1);
		
		t2 = new JLabel("Officers department");     //profile_id
		t2.setBounds(50, 240, 350, 30);
		t2.setForeground(Color.white);
		t2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		panel.add(t2);
		
		
		String columns1[] =  {"Department ID","Department Name", "Admission Fee"};
		JTable contactTable1 = new JTable();
		DefaultTableModel tableModel1;
		// specify number of columns
		tableModel1 = new DefaultTableModel(0,2); 
		tableModel1.setColumnIdentifiers(columns1);
		contactTable1.setModel(tableModel1);
		tableScrollPane1 = new JScrollPane(contactTable1);
		tableScrollPane1.setBounds(50,100,650,80);
		panel.add(tableScrollPane1);
		
		String columns2[] =  {"Department ID","Department Name"};
		JTable contactTable2 = new JTable();
		DefaultTableModel tableModel2;
		// specify number of columns
		tableModel2 = new DefaultTableModel(0,2); 
		tableModel2.setColumnIdentifiers(columns2);
		contactTable2.setModel(tableModel2);
		tableScrollPane2 = new JScrollPane(contactTable2);
		tableScrollPane2.setBounds(50,280,650,80);
		panel.add(tableScrollPane2);
		
		search1 = new JButton("Search FD");
		search1.setBounds(350, 190, 100, 30);
		search1.addActionListener(this);
		panel.add(search1);
		
		search2= new JButton("Search OD");
		search2.setBounds(350, 370, 100, 30);
		search2.addActionListener(this);
		panel.add(search2);
		
		search_field1 = new JTextField("Department name");
		search_field1.setBounds(200,190,100,30);
		search_field1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,10));
		search_field1.addFocusListener(this);
		panel.add(search_field1);
		
		search_field2 = new JTextField("Department name");
		search_field2.setBounds(200,370,100,30);
		search_field2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,10));
		search_field2.addFocusListener(this);
		panel.add(search_field2);
		
		back = new JButton("Back");
		back.setBounds(470, 370, 100, 30);
		back.addActionListener(this);
		panel.add(back);

	
		
		
		String query1 = "SELECT `dept_id`, `d_name`, `add_fee` FROM `depertment`;";   
		String query2 = "SELECT `od_id`, `od_name` FROM `odept`;";		
        Connection con=null;//for connection
        Statement st1 = null;//for query execution
		Statement st2 = null;//for query execution
		ResultSet rs1 = null;//to get row by row result from DB
		ResultSet rs2 = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st1 = con.createStatement();//create statement
			st2 = con.createStatement();//create statement
			rs1 = st1.executeQuery(query1);//getting result
			rs2 = st2.executeQuery(query2);//getting result
			
			while(rs1.next())
			{
                String F_id = rs1.getString("dept_id");
                String F_name = rs1.getString("d_name");
				String F_fee = rs1.getString("add_fee");
				
				tableModel1.addRow(new Object[]{F_id, F_name, F_fee});
			}
			
			while(rs2.next())
			{
                String F_id = rs2.getString("od_id");
                String F_name = rs2.getString("od_name");
				
				tableModel2.addRow(new Object[]{F_id, F_name});
			}
		}
		catch(Exception e){}
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);

		this.add(panel);
	}
	
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(search_field1))
					{search_field1.setText(""); }
				else if(e.getSource().equals(search_field2))
					{search_field2.setText(""); }
				else{}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(search_field1)&&search_field1.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter faculty dept. name");
					search_field1.setText("Department name");
				}
				else if(e.getSource().equals(search_field2)&&search_field2.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter faculty dept. name");
					search_field2.setText("Department name");
				}
		}
	
	
	
	public void Search1()
	{
		String Reg_noS=search_field1.getText();
	
		String columns[] =  {"Department ID","Department Name", "Admission Fee"}; 
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,100,650,80);
		panel.add(tableScrollPane);

		String query = "SELECT `dept_id`, `d_name`, `add_fee` FROM `depertment`;";   
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
				String F_id = rs.getString("dept_id");
                String F_name = rs.getString("d_name");
				String F_fee = rs.getString("add_fee");
				
				if(Reg_noS.equals(F_name))
					{
						tableModel.addRow(new Object[]{F_id, F_name, F_fee});
						break;			  
					}
			}
		}
		catch(Exception e){}
	}
	
	public void Search2()
	{
		String Reg_noS=search_field2.getText();
	
		String columns[] =  {"od_id","od_name"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,280,650,80);
		panel.add(tableScrollPane);

		String query = "SELECT `od_id`, `od_name` FROM `odept`;;";   
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
				String F_id = rs.getString("od_id");
                String F_name = rs.getString("od_name");
	
				if(Reg_noS.equals(F_name))
					{
						tableModel.addRow(new Object[]{F_id, F_name});
						break;			  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search1.getText()))
		{
			Search1();
		}
		if(buttonClicked.equals(search2.getText()))
		{
			Search2();
		}
		else if(buttonClicked.equals(back.getText()))
		{
			AddDepartment a = new AddDepartment(a_name,a_id,a_pass);
			a.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
