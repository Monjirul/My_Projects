import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class TakeCourse extends JFrame implements ActionListener
{                                       
	//private JTextField search_field;
	private JLabel AvailableCourses,F_name,F_dept,sec;
	//private JScrollPane tableScrollPane;
	private JButton Confirm, viewCourses,back;
	private JPanel panel;
	private String f_id, dept_id,f_name,f_pass,admin_id;
	private JComboBox combo,combo2;
	String c_name[] =new String[20];
	String dept_name;
	String C_ID,class_name;
	int flag=0;
	public TakeCourse(String f_id,String f_name,String f_Pass,String dept_id,String admin_id)
	{
		super("Take Course");
		this.setSize(800,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.f_id=f_id;
		this.dept_id=dept_id;
		this.admin_id=admin_id;
		this.f_pass=f_pass;
		this.f_name=f_name;
		//this.a_pass=a_pass;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		AvailableCourses=new JLabel("Available Courses :");
		AvailableCourses.setBounds(10, 100, 150, 30);
		panel.add(AvailableCourses);
		
				sec=new JLabel("Section :");
		sec.setBounds(360, 100, 150, 30);
		panel.add(sec);
		
		F_name=new JLabel("NAME :"+f_name);
		F_name.setBounds(10, 10, 150, 30);
		panel.add(F_name);
		
		//-------------------------------------------------------------
		
		
		
		String q = "SELECT `dept_id`, `c_name`,`c_id` FROM `course`;";
		String query2 = "SELECT `d_name`,`dept_id` FROM `depertment`;";
        try
		{
			int i=0;
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement st2 = con.createStatement();
			ResultSet rs = stm.executeQuery(q);
			ResultSet rs2 = st2.executeQuery(query2);
			
			while(rs.next())
			{
				String C_id=rs.getString("c_id");
				String C_name=rs.getString("c_name");
				String D_id= rs.getString("dept_id");
				if(dept_id.equals(D_id))
				{
					c_name[i]=C_name;
				}
			else{}
			}
			
				System.out.println("ist whiel end");
			while(rs2.next())
			{
				String D_name = rs2.getString("d_name");
				String D_id= rs2.getString("dept_id");
				if(dept_id.equals(D_id))
				{
			     	//System.out.println("Dept paiesi");
					dept_name=D_name;
				}
				else{
					
				}
			}
			System.out.println("2nd whiel end");
			st2.close();
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }

			
		//------------------------------------------------------------
		
			
		String s[] = {"A","B","C","D","E","F","G"};
		
		
	    combo = new JComboBox(c_name);
		combo.setBounds(150, 100, 120, 25);
		combo.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo);
		
		
		
		combo2 = new JComboBox(s);
		combo2.setBounds(420, 100, 120, 25);
		combo2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		panel.add(combo2);
		
		F_dept=new JLabel("Depertment :"+dept_name);
		F_dept.setBounds(10, 50, 150, 30);
		panel.add(F_dept);
	
	
	
		Confirm = new JButton("Confirm");
		Confirm.setBounds(140, 240, 150, 50);
		Confirm.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		Confirm.addActionListener(this);
		panel.add(Confirm);
	
	
	
		viewCourses = new JButton("View Courses");
		viewCourses.setBounds(360, 240, 150, 50);
		viewCourses.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		viewCourses.addActionListener(this);
		panel.add(viewCourses);
	
			back = new JButton("BACK");
		back.setBounds(450, 0, 80, 40);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		back.addActionListener(this);
		panel.add(back);

		this.add(panel);
	}
	
	

	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(Confirm.getText()))
		{
			insertIntoDB();
		}
		else if(buttonClicked.equals(back.getText()))
		{
			FacultyHome fh = new FacultyHome(f_id,f_name,f_pass,dept_id,admin_id);
			fh.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(viewCourses.getText()))
		{
			viewCourses vc = new viewCourses(f_id,f_name,f_pass,dept_id,admin_id);
			vc.setVisible(true);
			this.setVisible(false);
		}
		else{}

	}
	
	
	
	public void chkAvailable(String cn,String ci)
	{
		//String tmp=cn+"-"+ci;
		
		String q = "SELECT `dept_id`, `c_name`,`c_id` FROM `course`;";
		String query2 = "SELECT `class_id`,`c_id` FROM `f_course`;";
        try
		{
			int i=0;
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			Statement st2 = con.createStatement();
			ResultSet rs = stm.executeQuery(q);
			ResultSet rs2 = st2.executeQuery(query2);
			
			while(rs.next())
			{
				String C_id=rs.getString("c_id");
				String C_name=rs.getString("c_name");
				String D_id= rs.getString("dept_id");
				if(cn.equals(C_name))
				{
					C_ID=C_id;
				}
			else{}
			}
			String tmp=C_ID+"-"+ci;
				
			while(rs2.next())
			{
				String class_id = rs2.getString("class_id");
			
			String c1_id= rs2.getString("c_id");
				if(tmp.equals(class_id))
				{
			     	flag=1;
					
					
				}
				else{
					class_name=tmp;
				}
			}
		//	System.out.println("2nd whiel end");
			st2.close();
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
	}
	
	public void insertIntoDB()
	{
		
		String c_name=(String) combo.getSelectedItem();
		String cls_id=(String) combo2.getSelectedItem();
		
		chkAvailable(c_name,cls_id);
		if(flag==0){
		String query="INSERT INTO f_course VALUES ('"+f_id+"','"+C_ID+"','"+class_name+"');";
		//String q="INSERT INTO officers_sal VALUES ("+officer_salary.getText()+",'"+"O-"+r+"');";
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums", "root", "");
			Statement stm = con.createStatement();
			//Statement s= con.createStatement();
			stm.execute(query);
			//s.execute(q);
			stm.close();
			con.close();	
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
		
		System.out.println("---Row inserted---");
    }
	
	else if(flag==1){
		
		flag=0;
		JOptionPane.showMessageDialog(this,"Section Taken");
	}
	}

}
