import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

class AdminProfile extends JFrame implements ActionListener, FocusListener
{
	private JLabel profile_name, profile_id, profile_password, pass_label, imgLabel;
	private JButton logout, change_password, back;
	private JPanel panel;
	private JTextField password_field, old_password;
	private String a_name, a_id, a_pass;
	private ImageIcon img;
	
	
	public AdminProfile(String a_name,String a_id,String a_pass)
	{
		super("Admin Profile");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		this.a_name=a_name;
		this.a_id=a_id;
		this.a_pass=a_pass;
		
		
		profile_name = new JLabel("Name	: "+a_name);  //profile_name
		profile_name.setBounds(20, 110, 150, 30);
		profile_name.setForeground(Color.white);
		profile_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(profile_name);
		
		profile_id = new JLabel("ID	: "+a_id);     //profile_id
		profile_id.setBounds(20, 150, 150, 30);
		profile_id.setForeground(Color.white);
		profile_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(profile_id);
		
		
		
		pass_label = new JLabel("To change password :");  //department name
		pass_label.setBounds(400, 110, 300, 30);
		pass_label.setForeground(Color.white);
		pass_label.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(pass_label);
		
		old_password = new JTextField("Old password");         //password_field
		old_password.setBounds(400, 150, 150, 30);
		old_password.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		old_password.addFocusListener(this);
		panel.add(old_password);
		
		
		password_field = new JTextField("New password");         //password_field
		password_field.setBounds(400, 190, 150, 30);
		password_field.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,13));
		password_field.addFocusListener(this);
		panel.add(password_field);
		
		change_password = new JButton("Change Password");   //button change password
		change_password.setBounds(400, 230, 200, 40);
		change_password.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,18));
		change_password.addActionListener(this);
		panel.add(change_password);
		
		logout = new JButton("Logout");    //button logout
		logout.setBounds(130, 300, 100, 40);
		logout.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		logout.addActionListener(this);
		panel.add(logout);
		
		back = new JButton("Back");     //button back
		back.setBounds(250, 300, 100, 40);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		back.addActionListener(this);
		panel.add(back);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
		
	}
	
	public void focusGained(FocusEvent e) 
		{
			if(e.getSource().equals(old_password))
				old_password.setText(""); 
			else if(e.getSource().equals(password_field))
				password_field.setText(""); 
			else{}
		}

	public void focusLost(FocusEvent e)
		{
			if(e.getSource().equals(old_password)&&old_password.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter old password");
					old_password.setText("Old password");
				}
			else if(e.getSource().equals(password_field)&&password_field.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter new password");
					password_field.setText("New password");
				}
			else{}
		}
	
	
	
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		
		String buttonClicked = ae.getActionCommand();
			
		if(buttonClicked.equals(logout.getText()))
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(change_password.getText()))
		{
			if(old_password.getText().equals(a_pass))
				{
					String query = "SELECT `admin_name`, `admin_Id`, `ad_Pass` FROM `administrator`;";     
					Connection con=null;//for connection
					Statement st = null;//for query execution
					ResultSet rs = null;//to get row by row result from DB
					try
						{
							Class.forName("com.mysql.jdbc.Driver");//load driver
							con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
							st = con.createStatement();//create statement
							rs = st.executeQuery(query);//getting result
							System.out.println(a_id);
							query = "update administrator set ad_Pass='"+password_field.getText()+"' where admin_Id='"+a_id+"'";
							st.executeUpdate(query);
							st.close();
							con.close();
							rs.close();
						}
				catch(Exception e){}
			}
			else{JOptionPane.showMessageDialog(this,"Password Mismatch");}
		}
		else if(buttonClicked.equals(back.getText()))
		{
			AdminHome a = new AdminHome(a_name,a_id,a_pass);
			a.setVisible(true);
			this.setVisible(false);
		}
		else{}
	}
	
	
}