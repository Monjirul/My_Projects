import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import java.sql.*;


public class JtableAdmissionExam extends JFrame implements ActionListener, FocusListener
{
	private JLabel imgLabel;
	private JTextField search_field;
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back, search;
	private JPanel panel;
	private String o_id, o_name, of_pass, a_id, od_id;
	private ImageIcon img;	
	
	public JtableAdmissionExam(String o_id, String o_name, String od_id, String of_pass, String a_id)
	{
		super("Admission Exam detail");
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.a_id=a_id;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		String columns[] =  {"Student name","HSC Reg. no.","Exam date","Time","Marks"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
		// specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,80,650,250);
		panel.add(tableScrollPane);
		
		
		search = new JButton("SEARCH");
		search.setBounds(350, 350, 100, 30);
		search.addActionListener(this);
		panel.add(search);
		
		search_field = new JTextField("Student name");
		search_field.setBounds(200,350,100,30);
		search_field.addFocusListener(this);
		panel.add(search_field);
		
		back = new JButton("Back");
		back.setBounds(470, 350, 100, 30);
		back.addActionListener(this);
		panel.add(back);

	
		
		
		String query = "SELECT `exam_date`, `time`, `marks_ob`, addmission_exam.hsc_reg_no, `r_name` FROM `addmission_exam`, `regestration` WHERE addmission_exam.hsc_reg_no=regestration.hsc_reg_no;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		
		
 
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
			
			while(rs.next())
			{
                String Date = rs.getString("exam_date");
                String Time = rs.getString("time");
				String Room_no = rs.getString("r_name");
				double Marks_ob = rs.getDouble("marks_ob");
				String Hsc_reg_no = rs.getString("hsc_reg_no");
				
				tableModel.addRow(new Object[]{Room_no, Hsc_reg_no, Date, Time, Marks_ob});
			}
		}
		catch(Exception e){}
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);

		this.add(panel);
	}
	
	
	public void focusGained(FocusEvent e) 
			{
				if(e.getSource().equals(search_field))
					{search_field.setText("");}
			}

	public void focusLost(FocusEvent e)
		{
				if(e.getSource().equals(search_field)&&search_field.getText().equals(""))
				{
					JOptionPane.showMessageDialog(this,"Please Enter student name");
					search_field.setText("Student name");
				}
				else{}
		}
	
	public void Search()
	{
		String Reg_noS=search_field.getText();
	
		String columns[] =  {"Student name","HSC Reg. no.","Exam date","Time","Marks"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(50,80,650,250);
		panel.add(tableScrollPane);

		String query = "SELECT `exam_date`, `time`, `marks_ob`, addmission_exam.hsc_reg_no, `r_name` FROM `addmission_exam`, `regestration` WHERE addmission_exam.hsc_reg_no=regestration.hsc_reg_no;";   
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB

			
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ums","root","");
			st = con.createStatement();//create statement
			rs = st.executeQuery(query);//getting result
		
			while(rs.next())
			{
                String Date = rs.getString("exam_date");
                String Time = rs.getString("time");
				String Room_no = rs.getString("r_name");
				double Marks_ob = rs.getDouble("marks_ob");
				String Hsc_reg_no = rs.getString("hsc_reg_no");
				
				
				if(Reg_noS.equals(Room_no))
					{
						tableModel.addRow(new Object[]{Room_no, Hsc_reg_no, Date, Time, Marks_ob});		  
					}
			}
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(search.getText()))
		{
			Search();
		}
		else if(buttonClicked.equals(back.getText()))
		{
			AdmissionExam ad = new AdmissionExam(o_id, o_name, od_id, of_pass, a_id);
			ad.setVisible(true);
			this.setVisible(false);
		}

	}
	

}
