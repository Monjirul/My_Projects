import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;

public class OfficerHome extends JFrame implements ActionListener
{
	private JLabel officer_name, officer_id, imgLabel;
	private JButton registration, logout, admission_exam, admission, profile;
	private JPanel panel;
	private JLabel Ename,Eposition,Eid,Esal;
	private String o_id, o_name, of_pass, admin_id, od_id;
	private ImageIcon img;

	
	
	
	public OfficerHome(String o_id, String o_name, String od_id, String of_pass, String admin_id)
	{
		super("Officer Home Window");
		
		this.setSize(818, 493);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		this.o_id=o_id;
		this.o_name=o_name;
		this.of_pass=of_pass;
		this.od_id=od_id;
		this.admin_id=admin_id;

		

		officer_name = new JLabel("Logged In: "+o_name);  //Officer Name
		officer_name.setForeground(Color.white);
		officer_name.setBounds(20, 130, 350, 30);
		officer_name.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(officer_name);
		
		officer_id = new JLabel("ID: "+o_id);   //Officer ID
		officer_id.setForeground(Color.white);
		officer_id.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		officer_id.setBounds(20, 180, 200, 30);
		panel.add(officer_id);
	
		
		profile = new JButton("Profile");    //profile button
		profile.setBounds(20, 300, 150, 50);
		profile.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		profile.addActionListener(this);
		panel.add(profile);
		
		
		registration = new JButton("Student Reg"); //admission registration
		registration.setBounds(500, 150, 200, 60);
		registration.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		registration.addActionListener(this);
		panel.add(registration);

		admission_exam = new JButton("Admission Exam");  //Admission exam 
		admission_exam.setBounds(500, 230, 200, 60);
		admission_exam.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		admission_exam.addActionListener(this);
		panel.add(admission_exam);
		
		admission = new JButton("Admission");  //Admission exam 
		admission.setBounds(500, 310, 200, 60);
		admission.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		admission.addActionListener(this);
		panel.add(admission);
		
		logout = new JButton("Logout");     //logout
		logout.setBounds(190, 300, 150, 50);
		logout.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		logout.addActionListener(this);
		panel.add(logout);
		
		img = new ImageIcon("u.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0,0,800,450);
		panel.add(imgLabel);
		
		
		this.add(panel);
	}
	
	
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String buttonClicked = ae.getActionCommand();
		
		if(buttonClicked.equals(profile.getText()))    //Profile gui
		{
			System.out.println(of_pass);
			OficcerProfile p= new OficcerProfile(o_id, o_name, od_id, of_pass, admin_id);
			p.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(registration.getText()))   //registration gui
		{
			RegPage r = new RegPage(o_id, o_name, od_id, of_pass, admin_id);
			r.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(admission_exam.getText())) //admission_exam gui
		{
			AdmissionExam ad = new AdmissionExam(o_id, o_name, od_id, of_pass, admin_id);
			ad.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(admission.getText())) //admission gui
		{
			Admission a = new Admission(o_id, o_name, od_id, of_pass, admin_id);
			a.setVisible(true);
			this.setVisible(false);
		}
		else if(buttonClicked.equals(logout.getText()))  //logout
		{
			Login l = new Login();
			l.setVisible(true);
			this.setVisible(false);
		}
	}
	
	
}