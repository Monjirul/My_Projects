#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<windows.h>
using namespace std;
class Quiz
{

public :
      string Ans[3];
     string Options[12];
string get_Q_file(int i)
{
    ifstream read("questions.txt");
       string line;
      int e;
      string Questions[3];
	    for(e=0;e<3;e++)
        {
		getline(read,line);
		Questions[e]=line;

         }
return Questions[i];
}
void get_opt_file()
{
     ifstream read("options.txt");
       string line;
       string random;

      int e;

	    for( e=0;e<12;e++)
        {
		getline(read,line);
		Options[e]=line;

         }
}
string correct_ans(int i)
{
       ifstream read("correctans.txt");
       string line;
       int e;

	    for(e=0;e<3;e++)
        {
		getline(read,line);
		Ans[e]=line;

         }
return Ans[i];

}


};
int main()
{
     Quiz q;
     int i,j,k=0;
   q.get_opt_file();
   system("color fc");
  for (i=0,j=0;i<3,j<12;i++,j+=4){
      cout<< q.get_Q_file(i)<<endl;

      cout<<q.Options[j]<<endl<<q.Options[j+1]<<endl
      <<q.Options[j+3]<<endl<<q.Options[j+2]<<endl;
        cout<<"For Hint Press 0 "<<endl;
        cout<<"\n\nEnter Your Answer : "<<endl;
        cin>>k;
           try
        {
            if(k>=5||k<0)
                throw "Invalid Option";
        }
        catch(char const *c)
        {
            cout<<c<<endl;
        }
        if(k==0)
        {
           cout<<q.correct_ans(i)<<endl;

         if(q.Options[j]==q.correct_ans(i))
        {

         cout<<q.Options[j+1]<<endl;

         }
       else{cout<<q.Options[j]<<endl;}
           cout<<"\n\nEnter Your Answer : "<<endl;
             cin>>k;

        }
      if(k==1)
        k=j;
              if(k==2)
        k=j+1;
              if(k==3)
        k=j+2;
              if(k==4)
        k=j+3;

        if(q.Options[k]== q.correct_ans(i))
        {
            cout<<"CORRECT ANSWER"<<endl;
            cout<<k;
        }
         if(q.Options[k]!= q.correct_ans(i))
            {
                  cout<<"WRONG"<<endl;

                 cout<<k<<" "<< q.correct_ans(i)<<endl;

        }

      system("pause");
      system("cls");
       }

}
