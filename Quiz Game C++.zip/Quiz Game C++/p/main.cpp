#include<iostream>
#include<fstream>
#include<stdlib.h>

using namespace std;
static int max_hint=0;
static int score=0;
class Quiz
{

public :

      string Ans[10];
     string Options[50];
string get_Q_file(int i)
{
    ifstream read("questions.txt");
       string line;
      int e;
      string Questions[10];
	    for(e=0;e<10;e++)
        {
		getline(read,line);
		Questions[e]=line;

         }
return Questions[i];
}
void get_opt_file()
{
     ifstream read("options.txt");
       string line;


      int e;

	    for( e=0;e<50;e++)
        {
		getline(read,line);
		Options[e]=line;

         }
}
string correct_ans(int i)
{
       ifstream read("correctans.txt");
       string line;
       int e;

	    for(e=0;e<10;e++)
        {
		getline(read,line);
		Ans[e]=line;

         }
return Ans[i];

}
void r_or_w(int k,int i,int j)
{
            if(k==1)
        k=j;
              if(k==2)
        k=j+1;
              if(k==3)
        k=j+2;
              if(k==4)
        k=j+3;
              if(k==5)
        k=j+4;

            if(Options[k]== correct_ans(i))
        {
            cout<<"\n\nCORRECT ANSWER\n\n"<<endl;
            score+=5;

        }
         if(Options[k]!= correct_ans(i))
            {
                  cout<<"\n\nWRONG\n\n"<<endl;
score-=5;


        }

}
void Hinted(int i,int j)
{
    max_hint++;

         int k,r=0;
      for(r=0;r<6;r++)
{
      if(max_hint>3)
      {
          cout<<"NO MORE HINTS FOR YOU."<<endl;
          break;
      }
         if(Options[j+r]!=correct_ans(i)&&Options[j+r+1]!=correct_ans(i))
        {
         cout<<"(1)"<<Options[j+r]<<endl;
         cout<<"(2)"<<correct_ans(i)<<endl;
         cout<<"(3)"<<Options[j+r+1]<<endl;

        break;
         }

}
           cout<<"\n\nEnter Your Answer : "<<endl;
             cin>>k;


if(k==2)
{
   cout<<"CORRECT ANSWER"<<endl;
score+=5;
}
else{cout<<"WRONG"<<endl;
score-=5;
}

        }

};
int main()
{
     Quiz q;
     int i,j,k=0;
   q.get_opt_file();
   system("color fc");
      for (i=0,j=0;i<10,j<50;i++,j+=5){
      cout<< q.get_Q_file(i)<<endl<<endl;

      cout<<"(1)"<<q.Options[j]<<endl<<"(2)"<<q.Options[j+1]<<endl
      <<"(3)"<<q.Options[j+2]<<endl<<"(4)"<<q.Options[j+3]<<endl
      <<"(5)"<<q.Options[j+4]<<endl;
        cout<<"\n\nFor Hint Press 0 "<<endl;
        cout<<"\n\nEnter Your Answer : "<<endl;
        cin>>k;
           try
        {
            if(k>=6||k<0)
                throw "Invalid Option";
        }
                catch(char const *c)
        {
            cout<<c<<endl;
        }
        if(k==0)
        {
            q.Hinted(i,j);
        }

     else{ q.r_or_w(k,i,j);}


      system("pause");
      system("cls");
       }
     cout<<"YOUR SCORE IS :: "<<score<<endl;
     return 0;
}
